#pragma once

#include "camera/CameraState.hpp"

#include <cstddef>


namespace levifreecam::camera {


class CameraController final {

public:

    static
    CameraController&
    instance()
        noexcept;


    bool readPosition(
        const void* cameraComponent,
        Vec3& out
    ) const noexcept;


    bool writePosition(
        void* cameraComponent,
        const Vec3& position
    ) const noexcept;


    bool applyOffset(
        void* cameraComponent,
        const Vec3& offset
    ) const noexcept;


    bool readOrientation(
        const void* cameraComponent,
        CameraOrientation& out
    ) const noexcept;


    bool writeOrientation(
        void* cameraComponent,
        const CameraOrientation& orientation
    ) const noexcept;


    bool copyTransform(
        void* destination,
        const void* source
    ) const noexcept;


    bool setTransform(
        void* cameraComponent,
        const Vec3& position,
        const CameraOrientation& orientation
    ) const noexcept;


    /*
     * =========================================================
     * Exact target binary:
     *
     * Build ID:
     * b480c79a54f33d6e4f0d63a131673e3daf749911
     *
     * Active camera transform function:
     *
     *     STUR Q0, [X19,#0x28]
     *
     * and position:
     *
     *     [X19,#0x38]
     *     [X19,#0x3C]
     *     [X19,#0x40]
     *
     * Therefore these two offsets are validated for this
     * specific binary.
     * =========================================================
     */

    static constexpr
    std::size_t
        kOrientationOffset =
            0x28;


    static constexpr
    std::size_t
        kPositionOffset =
            0x38;


private:

    CameraController()
        = default;
};


} // namespace levifreecam::camera
