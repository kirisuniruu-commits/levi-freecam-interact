#include "camera/NativeCameraController.hpp"

#include "camera/CameraController.hpp"

#include <android/log.h>

#include <cmath>


namespace levifreecam::camera {


namespace {


constexpr char
    kLogTag[] =
        "Levi Freecam";


constexpr float
    kDeadZone =
        0.001f;


constexpr float
    kVectorEpsilon =
        0.00001f;


[[nodiscard]]
float lengthSquared(
    const Vec3& value
) noexcept {

    return

        value.x *
        value.x

        +

        value.y *
        value.y

        +

        value.z *
        value.z;
}


bool normalize(
    Vec3& value
) noexcept {

    const float lengthSq =
        lengthSquared(
            value
        );


    if (
        !std::isfinite(
            lengthSq
        )

        ||

        lengthSq <
            kVectorEpsilon
    ) {

        return false;
    }


    const float inverseLength =
        1.0f /
        std::sqrt(
            lengthSq
        );


    value.x *=
        inverseLength;


    value.y *=
        inverseLength;


    value.z *=
        inverseLength;


    return true;
}


bool cameraBasis(
    const CameraOrientation& orientation,
    Vec3& forward,
    Vec3& right
) noexcept {

    float x =
        orientation.value[0];


    float y =
        orientation.value[1];


    float z =
        orientation.value[2];


    float w =
        orientation.value[3];


    const float quaternionLengthSquared =

        x * x +
        y * y +
        z * z +
        w * w;


    if (
        !std::isfinite(
            quaternionLengthSquared
        )

        ||

        quaternionLengthSquared <
            0.01f

        ||

        quaternionLengthSquared >
            100.0f
    ) {

        return false;
    }


    const float inverseLength =
        1.0f /
        std::sqrt(
            quaternionLengthSquared
        );


    x *= inverseLength;
    y *= inverseLength;
    z *= inverseLength;
    w *= inverseLength;


    /*
     * Canonical Minecraft +Z forward.
     */
    forward.x =
        2.0f *
        (
            x * z +
            w * y
        );


    forward.y =
        0.0f;


    forward.z =
        1.0f -
        2.0f *
        (
            x * x +
            y * y
        );


    if (
        !normalize(
            forward
        )
    ) {

        return false;
    }


    right.x =
        forward.z;


    right.y =
        0.0f;


    right.z =
        -forward.x;


    return
        normalize(
            right
        );
}


} // namespace


NativeCameraController&
NativeCameraController::instance()
    noexcept {

    static
    NativeCameraController
        controller;


    return controller;
}


bool
NativeCameraController::enable()
    noexcept {

    auto&
        state =
            getCameraState();


    if (
        state.enabled.load(
            std::memory_order_acquire
        )
    ) {

        return true;
    }


    state.position =
        {};


    state.originalPosition =
        {};


    state.velocity =
        {};


    state.input =
        {};


    state.orientation =
        {};


    state.originalOrientation =
        {};


    state.captureRequested.store(
        true,
        std::memory_order_release
    );


    state.captured.store(
        false,
        std::memory_order_release
    );


    state.detached.store(
        true,
        std::memory_order_release
    );


    state.enabled.store(
        true,
        std::memory_order_release
    );


    mMovementLogged.store(
        false,
        std::memory_order_relaxed
    );


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,
        "Freecam Stage-2C input-split enabled"
    );


    return true;
}


bool
NativeCameraController::disable()
    noexcept {

    auto&
        state =
            getCameraState();


    void*
        camera =
            mLastCameraComponent.load(
                std::memory_order_acquire
            );


    if (
        camera !=
            nullptr

        &&

        state.captured.load(
            std::memory_order_acquire
        )
    ) {

        CameraController::
            instance().
            setTransform(

                camera,

                state.originalPosition,

                state.originalOrientation
            );


        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Camera restored to original player transform"
        );
    }


    mLastCameraComponent.store(
        nullptr,
        std::memory_order_release
    );


    state.velocity =
        {};


    state.input =
        {};


    state.enabled.store(
        false,
        std::memory_order_release
    );


    state.captured.store(
        false,
        std::memory_order_release
    );


    state.captureRequested.store(
        false,
        std::memory_order_release
    );


    state.detached.store(
        false,
        std::memory_order_release
    );


    return true;
}


bool
NativeCameraController::isEnabled()
    const noexcept {

    return
        getCameraState().
            enabled.load(
                std::memory_order_acquire
            );
}


bool
NativeCameraController::cameraCaptured()
    const noexcept {

    return
        getCameraState().
            captured.load(
                std::memory_order_acquire
            );
}


void
NativeCameraController::requestRecapture()
    noexcept {

    getCameraState().
        captureRequested.store(
            true,
            std::memory_order_release
        );
}


void
NativeCameraController::onCameraTransform(
    void* cameraComponent
) noexcept {

    if (
        cameraComponent ==
        nullptr
    ) {

        return;
    }


    auto&
        state =
            getCameraState();


    if (
        !state.enabled.load(
            std::memory_order_acquire
        )
    ) {

        return;
    }


    mLastCameraComponent.store(
        cameraComponent,
        std::memory_order_release
    );


    Vec3
        vanillaPosition{};


    CameraOrientation
        vanillaOrientation{};


    const bool positionOK =

        CameraController::
            instance().
            readPosition(

                cameraComponent,

                vanillaPosition
            );


    const bool orientationOK =

        CameraController::
            instance().
            readOrientation(

                cameraComponent,

                vanillaOrientation
            );


    if (
        state.captureRequested.load(
            std::memory_order_acquire
        )
    ) {

        if (
            !positionOK ||
            !orientationOK
        ) {

            return;
        }


        state.originalPosition =
            vanillaPosition;


        state.position =
            vanillaPosition;


        state.originalOrientation =
            vanillaOrientation;


        state.orientation =
            vanillaOrientation;


        state.velocity =
            {};


        state.captureRequested.store(
            false,
            std::memory_order_release
        );


        state.captured.store(
            true,
            std::memory_order_release
        );


        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Camera transform captured successfully"
        );
    }


    if (
        !state.captured.load(
            std::memory_order_acquire
        )
    ) {

        return;
    }


    /*
     * Keep vanilla touch-look.
     */
    if (
        orientationOK
    ) {

        state.orientation =
            vanillaOrientation;
    }


    /*
     * Replace only camera position.
     */
    CameraController::
        instance().
        writePosition(

            cameraComponent,

            state.position
        );
}


void
NativeCameraController::update()
    noexcept {

    auto&
        state =
            getCameraState();


    if (
        !state.enabled.load(
            std::memory_order_acquire
        )

        ||

        !state.captured.load(
            std::memory_order_acquire
        )
    ) {

        return;
    }


    const CameraMoveInput
        input =
            state.input;


    if (
        !input.valid
    ) {

        state.velocity =
            {};


        return;
    }


    if (
        std::fabs(
            input.strafe
        ) <
            kDeadZone

        &&

        std::fabs(
            input.forward
        ) <
            kDeadZone

        &&

        std::fabs(
            input.vertical
        ) <
            kDeadZone
    ) {

        state.velocity =
            {};


        return;
    }


    Vec3
        forward{
            0.0f,
            0.0f,
            1.0f
        };


    Vec3
        right{
            1.0f,
            0.0f,
            0.0f
        };


    cameraBasis(
        state.orientation,
        forward,
        right
    );


    Vec3 movement{};


    movement.x =

        forward.x *
            input.forward

        +

        right.x *
            input.strafe;


    movement.z =

        forward.z *
            input.forward

        +

        right.z *
            input.strafe;


    movement.y =
        input.vertical;


    /*
     * No diagonal speed boost.
     */
    if (
        lengthSquared(
            movement
        ) >
            1.0f
    ) {

        normalize(
            movement
        );
    }


    float speed =
        state.moveSpeed;


    if (
        input.sprint
    ) {

        speed *=
            state.sprintMultiplier;
    }


    state.velocity.x =
        movement.x *
        speed;


    state.velocity.y =
        movement.y *
        speed;


    state.velocity.z =
        movement.z *
        speed;


    state.position.x +=
        state.velocity.x;


    state.position.y +=
        state.velocity.y;


    state.position.z +=
        state.velocity.z;


    bool expected =
        false;


    if (
        mMovementLogged.
            compare_exchange_strong(
                expected,
                true
            )
    ) {

        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,

            "Camera consuming split input: strafe=%.3f forward=%.3f vertical=%.3f",

            input.strafe,
            input.forward,
            input.vertical
        );
    }
}


void
NativeCameraController::translate(
    float x,
    float y,
    float z
) noexcept {

    auto&
        state =
            getCameraState();


    if (
        !state.enabled.load(
            std::memory_order_acquire
        )
    ) {

        return;
    }


    state.position.x +=
        x;


    state.position.y +=
        y;


    state.position.z +=
        z;
}


void
NativeCameraController::rotate(
    float yawDelta,
    float pitchDelta
) noexcept {

    auto&
        state =
            getCameraState();


    if (
        !state.enabled.load(
            std::memory_order_acquire
        )
    ) {

        return;
    }


    state.yaw +=
        yawDelta *
        state.sensitivity;


    state.pitch +=
        pitchDelta *
        state.sensitivity;
}


} // namespace levifreecam::camera
