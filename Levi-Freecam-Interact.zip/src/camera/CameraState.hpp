#pragma once

#include <atomic>


namespace levifreecam::camera {


struct Vec3 final {

    float x{
        0.0f
    };

    float y{
        0.0f
    };

    float z{
        0.0f
    };
};


struct CameraOrientation final {

    float value[4]{
        0.0f,
        0.0f,
        0.0f,
        1.0f
    };
};


struct CameraMoveInput final {

    float strafe{
        0.0f
    };


    float forward{
        0.0f
    };


    float vertical{
        0.0f
    };


    bool sprint{
        false
    };


    bool valid{
        false
    };
};


struct CameraState final {

    std::atomic_bool
        enabled{
            false
        };


    std::atomic_bool
        captureRequested{
            false
        };


    std::atomic_bool
        captured{
            false
        };


    std::atomic_bool
        detached{
            false
        };


    /*
     * Independent Freecam position.
     */
    Vec3
        position{};


    Vec3
        originalPosition{};


    Vec3
        velocity{};


    CameraOrientation
        orientation{};


    CameraOrientation
        originalOrientation{};


    CameraMoveInput
        input{};


    /*
     * Per LocalPlayer tick.
     *
     * ~0.35 blocks/tick = ~7 blocks/s at 20 TPS.
     */
    float
        moveSpeed{
            0.35f
        };


    float
        sprintMultiplier{
            2.0f
        };


    float
        yaw{
            0.0f
        };


    float
        pitch{
            0.0f
        };


    float
        sensitivity{
            0.15f
        };
};


CameraState&
getCameraState()
    noexcept;


} // namespace levifreecam::camera
