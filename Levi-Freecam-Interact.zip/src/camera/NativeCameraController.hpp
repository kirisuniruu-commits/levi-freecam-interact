#pragma once

#include "camera/CameraState.hpp"

#include <atomic>


namespace levifreecam::camera {


class NativeCameraController final {

public:

    static
    NativeCameraController&
    instance()
        noexcept;


    bool enable()
        noexcept;


    bool disable()
        noexcept;


    [[nodiscard]]
    bool isEnabled()
        const noexcept;


    [[nodiscard]]
    bool cameraCaptured()
        const noexcept;


    /*
     * Camera movement now consumes the input snapshot
     * captured BEFORE physical-player movement suppression.
     */
    void update()
        noexcept;


    void onCameraTransform(
        void* cameraComponent
    ) noexcept;


    void translate(
        float x,
        float y,
        float z
    ) noexcept;


    void rotate(
        float yawDelta,
        float pitchDelta
    ) noexcept;


    void requestRecapture()
        noexcept;


private:

    NativeCameraController()
        = default;


private:

    std::atomic<void*>
        mLastCameraComponent{
            nullptr
        };


    std::atomic_bool
        mMovementLogged{
            false
        };
};


} // namespace levifreecam::camera
