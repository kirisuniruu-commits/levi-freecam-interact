#include "camera/CameraSystemHook.hpp"

#include <android/log.h>

#include <cstdint>


namespace levifreecam::camera {


namespace {


constexpr char
    kLogTag[] =
        "Levi Freecam";


bool
    gInstalled =
        false;


} // namespace


/*
 * ============================================================
 * Stage-2G compatibility stub
 * ============================================================
 *
 * Stage-2F mencoba melakukan early-return pada kandidat
 * UpdatePlayerFromCamera.
 *
 * Runtime testing menunjukkan:
 *
 * - body/head masih mengikuti camera
 * - target tersebut bukan satu-satunya producer rotation
 *
 * Jadi Stage-2G tidak melakukan native hook apa pun di sini.
 *
 * Rotation isolation sekarang dilakukan melalui:
 *
 * PlayerFreezeController
 *      +
 * validated ActiveCameraTransform hook.
 */


bool
installCameraSystemHook()
    noexcept {

    if (
        gInstalled
    ) {

        return true;
    }


    gInstalled =
        true;


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,
        "Stage-2G CameraSystemHook bypassed - rotation isolation moved to camera render path"
    );


    return true;
}


void
removeCameraSystemHook()
    noexcept {

    gInstalled =
        false;
}


bool
cameraSystemHookInstalled()
    noexcept {

    return gInstalled;
}


std::uintptr_t
cameraSystemAddress()
    noexcept {

    /*
     * No native target installed.
     */
    return 0;
}


std::uintptr_t
lastCameraSystem()
    noexcept {

    return 0;
}


std::uintptr_t
lastCameraRegistry()
    noexcept {

    return 0;
}


} // namespace levifreecam::camera
