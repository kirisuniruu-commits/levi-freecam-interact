#include "camera/CameraHook.hpp"
#include "camera/CameraEntityTracker.hpp"
#include "camera/CameraState.hpp"
#include "camera/NativeCameraController.hpp"

#include "core/PlayerFreezeController.hpp"

#include "memory/CameraResolver.hpp"

#include <android/log.h>

#include <cstdint>

#include <pl/memory/Hook.hpp>


namespace levifreecam::camera {


namespace {


constexpr char
    kLogTag[] =
        "Levi Freecam";


using ActiveCameraTransformFn =
    void (*)(
        void* shakeSupport,
        void* cameraComponent,
        void* runtimeContext
    );


ActiveCameraTransformFn
    gOriginalActiveCameraTransform =
        nullptr;


void*
    gHookTarget =
        nullptr;


std::uintptr_t
    gTargetAddress =
        0;


bool
    gInstalled =
        false;


std::uint64_t
    gCallCounter =
        0;


void*
    gLastCameraComponent =
        nullptr;


/*
 * ============================================================
 * Active camera transform
 * ============================================================
 */


void activeCameraTransformDetour(
    void* shakeSupport,
    void* cameraComponent,
    void* runtimeContext
) {

    /*
     * Vanilla tetap menghitung:
     *
     * - touch look
     * - camera orientation
     * - matrices
     */
    if (
        gOriginalActiveCameraTransform !=
        nullptr
    ) {

        gOriginalActiveCameraTransform(

            shakeSupport,

            cameraComponent,

            runtimeContext
        );
    }


    if (
        cameraComponent ==
        nullptr
    ) {

        return;
    }


    ++gCallCounter;


    if (
        cameraComponent !=
        gLastCameraComponent
    ) {

        gLastCameraComponent =
            cameraComponent;


        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,

            "Camera component updated: %p",

            cameraComponent
        );
    }


    auto&
        state =
            getCameraState();


    if (
        !state.enabled.load(
            std::memory_order_acquire
        )
    ) {

        return;
    }


    /*
     * =========================================================
     * Stage-2G rotation isolation
     * =========================================================
     *
     * Camera vanilla telah selesai menghitung look.
     *
     * Tepat sekarang kita kembalikan:
     *
     * ActorRotation
     * HeadRotation
     * BodyRotation
     * RenderRotation
     *
     * milik physical player.
     *
     * CameraComponent TIDAK disentuh.
     *
     * Hasil yang diinginkan:
     *
     * touch drag
     *      |
     *      +--> camera rotates
     *
     * physical player
     *      |
     *      +--> rotation snapshot tetap
     */
    levifreecam::
        PlayerFreezeController::
        instance().
        restoreFrozenRotation();


    /*
     * Freecam camera takeover.
     */
    CameraEntityTracker::
        instance().
        track(
            cameraComponent
        );


    NativeCameraController::
        instance().
        onCameraTransform(
            cameraComponent
        );
}


} // namespace


bool
installCameraHook()
    noexcept {

    if (
        gInstalled
    ) {

        return true;
    }


    memory::CameraTargets
        targets{};


    if (
        !memory::
            resolveCameraTargets(
                targets
            )

        ||

        targets.
            activeCameraTransform ==
            0
    ) {

        __android_log_print(
            ANDROID_LOG_ERROR,
            kLogTag,
            "Failed to resolve camera targets"
        );


        return false;
    }


    void*
        target =

            reinterpret_cast<
                void*
            >(
                targets.
                    activeCameraTransform
            );


    void*
        detour =

            reinterpret_cast<
                void*
            >(
                &activeCameraTransformDetour
            );


    void*
        original =
            nullptr;


    const int
        result =

            pl::memory::
                hook(

                    target,

                    detour,

                    &original,

                    pl::memory::
                        HookPriority::
                            Normal
                );


    if (
        result !=
            0

        ||

        original ==
            nullptr
    ) {

        __android_log_print(
            ANDROID_LOG_ERROR,
            kLogTag,

            "Camera hook failed %d",

            result
        );


        return false;
    }


    gOriginalActiveCameraTransform =

        reinterpret_cast<
            ActiveCameraTransformFn
        >(
            original
        );


    gHookTarget =
        target;


    gTargetAddress =
        targets.
            activeCameraTransform;


    gInstalled =
        true;


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,

        "Camera hook installed %p",

        target
    );


    return true;
}


void
removeCameraHook()
    noexcept {

    if (
        !gInstalled
    ) {

        return;
    }


    if (
        gHookTarget !=
        nullptr
    ) {

        pl::memory::
            unhook(

                gHookTarget,

                reinterpret_cast<
                    void*
                >(
                    &activeCameraTransformDetour
                )
            );
    }


    gOriginalActiveCameraTransform =
        nullptr;


    gHookTarget =
        nullptr;


    gTargetAddress =
        0;


    gCallCounter =
        0;


    gLastCameraComponent =
        nullptr;


    gInstalled =
        false;


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,
        "Camera hook removed"
    );
}


bool
cameraHookInstalled()
    noexcept {

    return gInstalled;
}


std::uintptr_t
cameraHookTargetAddress()
    noexcept {

    return gTargetAddress;
}


} // namespace levifreecam::camera
