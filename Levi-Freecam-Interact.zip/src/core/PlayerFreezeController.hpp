#pragma once

#include <array>
#include <atomic>
#include <cstddef>


namespace levifreecam {


class PlayerFreezeController final {

public:

    static PlayerFreezeController&
    instance()
        noexcept;


    /*
     * Dipanggil sebelum
     * LocalPlayer::normalTick.
     */
    void preTick(
        void* player,
        bool active
    ) noexcept;


    /*
     * Dipanggil setelah
     * LocalPlayer::normalTick.
     */
    void postTick(
        void* player,
        bool active
    ) noexcept;


    /*
     * Logical disable.
     *
     * Tidak melakukan lookup ECS
     * secara langsung dari UI thread.
     */
    void disable()
        noexcept;


    [[nodiscard]]
    bool enabled()
        const noexcept;


    [[nodiscard]]
    bool nativeIsolationApplied()
        const noexcept;


    /*
     * Compatibility alias.
     */
    [[nodiscard]]
    bool stateCaptured()
        const noexcept;


    [[nodiscard]]
    void*
    player()
        const noexcept;


    /*
     * Dipanggil dari validated
     * active-camera-transform hook.
     *
     * Restore rotasi physical player
     * tanpa menyentuh CameraComponent.
     */
    void restoreFrozenRotation()
        noexcept;


private:

    PlayerFreezeController()
        = default;


    /*
     * PRE normalTick.
     *
     * Capture input untuk kamera,
     * lalu suppress physical input.
     */
    bool captureInputAndSuppress(
        void* player
    ) noexcept;


    /*
     * POST normalTick.
     *
     * Hanya suppress movement yang
     * dibentuk ulang oleh Minecraft.
     *
     * Tidak melakukan recapture
     * CameraState.input.
     */
    bool suppressMovementInput(
        void* player
    ) noexcept;


    /*
     * Capture seluruh rotation state
     * physical LocalPlayer ketika
     * sesi Freecam dimulai.
     */
    void captureRotation(
        void* player
    ) noexcept;


    /*
     * Restore:
     *
     * ActorRotationComponent
     * ActorHeadRotationComponent
     * MobBodyRotationComponent
     * RenderRotationComponent
     */
    void restoreRotation(
        void* player
    ) noexcept;


    /*
     * Reset seluruh state lokal
     * sesi Freecam.
     */
    void clearSession()
        noexcept;


private:

    /*
     * =========================================================
     * Main state
     * =========================================================
     */

    std::atomic_bool
        mEnabled{
            false
        };


    std::atomic_bool
        mIsolationApplied{
            false
        };


    std::atomic<void*>
        mPlayer{
            nullptr
        };


    /*
     * =========================================================
     * Rotation isolation
     * =========================================================
     */

    bool
        mRotationCaptured{
            false
        };


    bool
        mActorRotationValid{
            false
        };


    bool
        mHeadRotationValid{
            false
        };


    bool
        mBodyRotationValid{
            false
        };


    bool
        mRenderRotationValid{
            false
        };


    /*
     * ActorRotationComponent
     *
     * sizeof = 0x10
     */
    std::array<
        std::byte,
        0x10
    >
        mActorRotationSnapshot{};


    /*
     * ActorHeadRotationComponent
     *
     * sizeof = 0x08
     */
    std::array<
        std::byte,
        0x08
    >
        mHeadRotationSnapshot{};


    /*
     * MobBodyRotationComponent
     *
     * sizeof = 0x08
     */
    std::array<
        std::byte,
        0x08
    >
        mBodyRotationSnapshot{};


    /*
     * RenderRotationComponent
     *
     * sizeof = 0x08
     */
    std::array<
        std::byte,
        0x08
    >
        mRenderRotationSnapshot{};


    /*
     * =========================================================
     * Camera-only held input
     * =========================================================
     */

    /*
     * Continuous sneak/down state.
     */
    bool
        mSneakHeld{
            false
        };


    /*
     * Continuous jump/up state.
     */
    bool
        mJumpHeld{
            false
        };


    /*
     * Rising-edge tracker untuk
     * mobile toggle-sneak input.
     */
    bool
        mSneakToggleLast{
            false
        };


    /*
     * =========================================================
     * One-shot logging
     * =========================================================
     */

    bool
        mLoggedInputCapture{
            false
        };


    bool
        mLoggedSuppression{
            false
        };


    bool
        mLoggedRawInput{
            false
        };


    bool
        mLoggedRotation{
            false
        };


    bool
        mLoggedFailure{
            false
        };
};


} // namespace levifreecam
