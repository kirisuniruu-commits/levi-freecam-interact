#include "core/PlayerFreezeController.hpp"

#include "camera/CameraState.hpp"
#include "game/RawEcs.hpp"

#include <android/log.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>

namespace levifreecam {
namespace {

constexpr char kLogTag[] = "Levi Freecam";

constexpr std::uint32_t kRawMoveInputComponentHash       = 0x3613E513U;
constexpr std::uint32_t kActorRotationComponentHash      = 0x75DF36B7U;
constexpr std::uint32_t kActorHeadRotationComponentHash  = 0xBABE7211U;
constexpr std::uint32_t kMobBodyRotationComponentHash    = 0xD7F64BBAU;
constexpr std::uint32_t kRenderRotationComponentHash     = 0xD15944E2U;

struct RawMoveInputComponent final {
    game::MoveInputState mRawInput{};
    game::Vec2 mRawMove{};
};

static_assert(
    sizeof(RawMoveInputComponent) ==
    0x18
);

struct ActorRotationComponentRaw final {
    game::Vec2 mRot{};
    game::Vec2 mRotPrev{};
};

static_assert(
    sizeof(ActorRotationComponentRaw) ==
    0x10
);

struct ActorHeadRotationComponentRaw final {
    float mYHeadRot{0.0f};
    float mYHeadRotO{0.0f};
};

static_assert(
    sizeof(ActorHeadRotationComponentRaw) ==
    0x08
);

struct MobBodyRotationComponentRaw final {
    float mYBodyRot{0.0f};
    float mYBodyRotO{0.0f};
};

static_assert(
    sizeof(MobBodyRotationComponentRaw) ==
    0x08
);

struct RenderRotationComponentRaw final {
    game::Vec2 mRot{};
};

static_assert(
    sizeof(RenderRotationComponentRaw) ==
    0x08
);

[[nodiscard]]
float clampInput(
    float value
) noexcept {
    if (
        !std::isfinite(
            value
        )
    ) {
        return 0.0f;
    }

    return std::clamp(
        value,
        -1.0f,
        1.0f
    );
}

constexpr std::uint32_t stateBit(
    game::MoveInputState::Flag flag
) noexcept {
    return
        std::uint32_t{1}
        <<
        static_cast<std::uint32_t>(
            flag
        );
}

constexpr std::uint16_t componentBit(
    game::MoveInputComponent::Flag flag
) noexcept {
    return static_cast<std::uint16_t>(
        std::uint16_t{1}
        <<
        static_cast<std::uint16_t>(
            flag
        )
    );
}

constexpr std::uint32_t
    kPhysicalStateMask =

        stateBit(
            game::MoveInputState::
                Flag::SneakDown
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::SneakToggleDown
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::WantDownSlow
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::WantUpSlow
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::AscendBlock
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::DescendBlock
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::JumpDown
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::SprintDown
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::UpLeft
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::UpRight
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::DownLeft
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::DownRight
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::Up
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::Down
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::Left
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::Right
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::Ascend
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::Descend
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::ChangeHeight
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::SneakInputCurrentlyDown
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::SneakInputWasReleased
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::SneakInputWasPressed
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::JumpInputWasReleased
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::JumpInputWasPressed
        )

        |

        stateBit(
            game::MoveInputState::
                Flag::JumpInputCurrentlyDown
        );

constexpr std::uint16_t
    kPhysicalComponentMask =

        componentBit(
            game::MoveInputComponent::
                Flag::Sneaking
        )

        |

        componentBit(
            game::MoveInputComponent::
                Flag::Sprinting
        )

        |

        componentBit(
            game::MoveInputComponent::
                Flag::WantUp
        )

        |

        componentBit(
            game::MoveInputComponent::
                Flag::WantDown
        )

        |

        componentBit(
            game::MoveInputComponent::
                Flag::Jumping
        )

        |

        componentBit(
            game::MoveInputComponent::
                Flag::AutoJumpingInWater
        )

        |

        componentBit(
            game::MoveInputComponent::
                Flag::PersistSneak
        );

void suppressMoveComponent(
    game::MoveInputComponent&
        component
) noexcept {
    component.mMove =
        {};

    component
        .mInputState
        .mAnalogMoveVector =
            {};

    component
        .mRawInputState
        .mAnalogMoveVector =
            {};

    component.mDisplacement =
        {};

    component.mDisplacementDelta =
        {};

    /*
     * Jangan menyentuh:
     *
     * mLookDelta
     * mInteractDir
     * mCameraOrientation
     *
     * Camera touch-look masih
     * membutuhkan field tersebut.
     */

    component
        .mInputState
        .mFlagValues &=
            ~kPhysicalStateMask;

    component
        .mRawInputState
        .mFlagValues &=
            ~kPhysicalStateMask;

    component.mFlagValues &=
        static_cast<std::uint16_t>(
            ~kPhysicalComponentMask
        );

    component
        .mHoldAutoJumpInWaterTicks =
            0;
}

[[nodiscard]]
bool stateFlag(
    const game::MoveInputState*
        state,

    game::MoveInputState::Flag
        flag
) noexcept {
    return
        state != nullptr
        &&
        state->checkFlag(
            flag
        );
}

/*
 * ============================================================
 * Sneak input
 * ============================================================
 *
 * Camera hanya mengambil:
 *
 * SneakInputWasPressed
 * SneakInputWasReleased
 * SneakInputCurrentlyDown
 *
 * Jangan menggunakan:
 *
 * Sneaking
 * WantDown
 * SneakDown
 * SneakToggleDown
 * PersistSneak
 *
 * sebagai held-state kamera.
 *
 * State tersebut dapat mengikuti toggle/crouch Minecraft
 * dan menyebabkan kamera terkunci turun.
 */

[[nodiscard]]
bool anySneakPressed(
    const game::MoveInputComponent&
        input,

    const game::MoveInputState*
        externalRaw
) noexcept {
    return

        input
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        SneakInputWasPressed
            )

        ||

        input
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        SneakInputWasPressed
            )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    SneakInputWasPressed
        );
}

[[nodiscard]]
bool anySneakReleased(
    const game::MoveInputComponent&
        input,

    const game::MoveInputState*
        externalRaw
) noexcept {
    return

        input
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        SneakInputWasReleased
            )

        ||

        input
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        SneakInputWasReleased
            )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    SneakInputWasReleased
        );
}

[[nodiscard]]
bool anySneakHeld(
    const game::MoveInputComponent&
        input,

    const game::MoveInputState*
        externalRaw
) noexcept {
    return

        input
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        SneakInputCurrentlyDown
            )

        ||

        input
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        SneakInputCurrentlyDown
            )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    SneakInputCurrentlyDown
        );
}

/*
 * ============================================================
 * Jump input
 * ============================================================
 *
 * Path jump yang sekarang sudah berhasil
 * tidak diubah.
 */

[[nodiscard]]
bool anyJumpPressed(
    const game::MoveInputComponent&
        input,

    const game::MoveInputState*
        externalRaw
) noexcept {
    return

        input
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpInputWasPressed
            )

        ||

        input
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpInputWasPressed
            )

        ||

        input
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpDown
            )

        ||

        input
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpDown
            )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    JumpInputWasPressed
        )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    JumpDown
        );
}

[[nodiscard]]
bool anyJumpReleased(
    const game::MoveInputComponent&
        input,

    const game::MoveInputState*
        externalRaw
) noexcept {
    return

        input
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpInputWasReleased
            )

        ||

        input
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpInputWasReleased
            )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    JumpInputWasReleased
        );
}

[[nodiscard]]
bool anyJumpHeld(
    const game::MoveInputComponent&
        input,

    const game::MoveInputState*
        externalRaw
) noexcept {
    return

        input
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpInputCurrentlyDown
            )

        ||

        input
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpInputCurrentlyDown
            )

        ||

        input
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpDown
            )

        ||

        input
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        JumpDown
            )

        ||

        input.checkFlag(
            game::
                MoveInputComponent::
                Flag::
                    Jumping
        )

        ||

        input.checkFlag(
            game::
                MoveInputComponent::
                Flag::
                    WantUp
        )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    JumpInputCurrentlyDown
        )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    JumpDown
        );
}

void updateJumpHeldState(
    bool heldNow,
    bool pressed,
    bool released,
    bool& stored
) noexcept {
    if (
        heldNow

        ||

        pressed
    ) {
        stored =
            true;
    }
    else if (
        released
    ) {
        stored =
            false;
    }
}

/*
 * ============================================================
 * Stage-2K sneak HOLD
 * ============================================================
 *
 * Ini perubahan utama.
 *
 * Mobile tidak selalu mempertahankan
 * SneakInputCurrentlyDown pada setiap normalTick.
 *
 * Karena itu press/release edge menjadi authoritative:
 *
 * WasPressed
 *     -> ON
 *
 * WasReleased
 *     -> OFF
 *
 * CurrentlyDown
 *     -> penguat bila tersedia
 *
 * Jika satu tick tidak memiliki ketiganya,
 * pertahankan nilai sebelumnya.
 */

void updateSneakHeldState(
    bool heldNow,
    bool pressed,
    bool released,
    bool& stored
) noexcept {
    /*
     * RELEASE harus menang.
     *
     * Jangan izinkan stale CurrentlyDown
     * menahan kamera setelah jari dilepas.
     */
    if (
        released
    ) {
        stored =
            false;

        return;
    }

    if (
        heldNow

        ||

        pressed
    ) {
        stored =
            true;
    }

    /*
     * Tidak ada signal:
     *
     * JANGAN stored = false.
     *
     * Pertahankan state sampai
     * SneakInputWasReleased muncul.
     */
}

void applyVerticalInput(
    camera::CameraMoveInput&
        input,

    bool jumpHeld,
    bool sneakHeld
) noexcept {
    if (
        jumpHeld

        &&

        !sneakHeld
    ) {
        input.vertical =
            1.0f;
    }
    else if (
        sneakHeld

        &&

        !jumpHeld
    ) {
        input.vertical =
            -1.0f;
    }
    else {
        input.vertical =
            0.0f;
    }
}

} // namespace

PlayerFreezeController&
PlayerFreezeController::instance()
    noexcept {
    static
    PlayerFreezeController
        controller;

    return controller;
}

void
PlayerFreezeController::captureRotation(
    void* player
) noexcept {
    if (
        player == nullptr

        ||

        mRotationCaptured
    ) {
        return;
    }

    if (
        auto* value =
            game::
                findComponent<
                    ActorRotationComponentRaw
                >(
                    player,
                    kActorRotationComponentHash
                )
    ) {
        auto snapshot =
            *value;

        snapshot.mRotPrev =
            snapshot.mRot;

        std::memcpy(
            mActorRotationSnapshot.data(),
            &snapshot,
            sizeof(snapshot)
        );

        mActorRotationValid =
            true;
    }

    if (
        auto* value =
            game::
                findComponent<
                    ActorHeadRotationComponentRaw
                >(
                    player,
                    kActorHeadRotationComponentHash
                )
    ) {
        auto snapshot =
            *value;

        snapshot.mYHeadRotO =
            snapshot.mYHeadRot;

        std::memcpy(
            mHeadRotationSnapshot.data(),
            &snapshot,
            sizeof(snapshot)
        );

        mHeadRotationValid =
            true;
    }

    if (
        auto* value =
            game::
                findComponent<
                    MobBodyRotationComponentRaw
                >(
                    player,
                    kMobBodyRotationComponentHash
                )
    ) {
        auto snapshot =
            *value;

        snapshot.mYBodyRotO =
            snapshot.mYBodyRot;

        std::memcpy(
            mBodyRotationSnapshot.data(),
            &snapshot,
            sizeof(snapshot)
        );

        mBodyRotationValid =
            true;
    }

    if (
        auto* value =
            game::
                findComponent<
                    RenderRotationComponentRaw
                >(
                    player,
                    kRenderRotationComponentHash
                )
    ) {
        std::memcpy(
            mRenderRotationSnapshot.data(),
            value,
            sizeof(*value)
        );

        mRenderRotationValid =
            true;
    }

    mRotationCaptured =

        mActorRotationValid

        ||

        mHeadRotationValid

        ||

        mBodyRotationValid

        ||

        mRenderRotationValid;

    if (
        mRotationCaptured

        &&

        !mLoggedRotation
    ) {
        mLoggedRotation =
            true;

        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Stage-2K rotation snapshot actor=%d head=%d body=%d render=%d",
            mActorRotationValid ? 1 : 0,
            mHeadRotationValid ? 1 : 0,
            mBodyRotationValid ? 1 : 0,
            mRenderRotationValid ? 1 : 0
        );
    }
}

void
PlayerFreezeController::restoreRotation(
    void* player
) noexcept {
    if (
        !mRotationCaptured

        ||

        player == nullptr
    ) {
        return;
    }

    if (
        mActorRotationValid
    ) {
        if (
            auto* value =
                game::
                    findComponent<
                        ActorRotationComponentRaw
                    >(
                        player,
                        kActorRotationComponentHash
                    )
        ) {
            std::memcpy(
                value,
                mActorRotationSnapshot.data(),
                sizeof(*value)
            );
        }
    }

    if (
        mHeadRotationValid
    ) {
        if (
            auto* value =
                game::
                    findComponent<
                        ActorHeadRotationComponentRaw
                    >(
                        player,
                        kActorHeadRotationComponentHash
                    )
        ) {
            std::memcpy(
                value,
                mHeadRotationSnapshot.data(),
                sizeof(*value)
            );
        }
    }

    if (
        mBodyRotationValid
    ) {
        if (
            auto* value =
                game::
                    findComponent<
                        MobBodyRotationComponentRaw
                    >(
                        player,
                        kMobBodyRotationComponentHash
                    )
        ) {
            std::memcpy(
                value,
                mBodyRotationSnapshot.data(),
                sizeof(*value)
            );
        }
    }

    if (
        mRenderRotationValid
    ) {
        if (
            auto* value =
                game::
                    findComponent<
                        RenderRotationComponentRaw
                    >(
                        player,
                        kRenderRotationComponentHash
                    )
        ) {
            std::memcpy(
                value,
                mRenderRotationSnapshot.data(),
                sizeof(*value)
            );
        }
    }
}

void
PlayerFreezeController::
restoreFrozenRotation()
    noexcept {
    if (
        !mEnabled.load(
            std::memory_order_acquire
        )
    ) {
        return;
    }

    restoreRotation(
        mPlayer.load(
            std::memory_order_relaxed
        )
    );
}

bool
PlayerFreezeController::
captureInputAndSuppress(
    void* player
) noexcept {
    auto*
        input =
            game::
                findComponent<
                    game::MoveInputComponent
                >(
                    player,
                    game::
                        kMoveInputComponentHash
                );

    if (
        input == nullptr
    ) {
        if (
            !mLoggedFailure
        ) {
            mLoggedFailure =
                true;

            __android_log_print(
                ANDROID_LOG_ERROR,
                kLogTag,
                "MoveInputComponent lookup failed"
            );
        }

        return false;
    }

    /*
     * RawMoveInputComponent harus tetap READ ONLY.
     */
    auto*
        rawInput =
            game::
                findComponent<
                    RawMoveInputComponent
                >(
                    player,
                    kRawMoveInputComponentHash
                );

    const game::MoveInputComponent
        snapshot =
            *input;

    const game::MoveInputState*
        externalRaw =
            rawInput != nullptr
                ? &rawInput->mRawInput
                : nullptr;

    camera::CameraMoveInput
        cameraInput{};

    /*
     * Horizontal movement.
     *
     * Axis ini sudah terbukti benar di device:
     *
     * strafe  = -mMove.x
     * forward = -mMove.y
     */
    cameraInput.strafe =
        clampInput(
            -snapshot.mMove.x
        );

    cameraInput.forward =
        clampInput(
            -snapshot.mMove.y
        );

    /*
     * Raw analog fallback.
     */
    if (
        rawInput != nullptr

        &&

        std::fabs(
            cameraInput.strafe
        ) < 0.0001f

        &&

        std::fabs(
            cameraInput.forward
        ) < 0.0001f
    ) {
        cameraInput.strafe =
            clampInput(
                -rawInput->mRawMove.x
            );

        cameraInput.forward =
            clampInput(
                -rawInput->mRawMove.y
            );
    }

    /*
     * Stage-2K Sneak.
     */
    const bool
        sneakPressed =
            anySneakPressed(
                snapshot,
                externalRaw
            );

    const bool
        sneakReleased =
            anySneakReleased(
                snapshot,
                externalRaw
            );

    const bool
        sneakHeldNow =
            anySneakHeld(
                snapshot,
                externalRaw
            );

    updateSneakHeldState(
        sneakHeldNow,
        sneakPressed,
        sneakReleased,
        mSneakHeld
    );

    /*
     * Jump path tetap sama.
     */
    const bool
        jumpPressed =
            anyJumpPressed(
                snapshot,
                externalRaw
            );

    const bool
        jumpReleased =
            anyJumpReleased(
                snapshot,
                externalRaw
            );

    const bool
        jumpHeldNow =
            anyJumpHeld(
                snapshot,
                externalRaw
            );

    updateJumpHeldState(
        jumpHeldNow,
        jumpPressed,
        jumpReleased,
        mJumpHeld
    );

    applyVerticalInput(
        cameraInput,
        mJumpHeld,
        mSneakHeld
    );

    cameraInput.sprint =

        snapshot
            .mInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        SprintDown
            )

        ||

        snapshot
            .mRawInputState
            .checkFlag(
                game::
                    MoveInputState::
                    Flag::
                        SprintDown
            )

        ||

        stateFlag(
            externalRaw,
            game::
                MoveInputState::
                Flag::
                    SprintDown
        )

        ||

        snapshot.checkFlag(
            game::
                MoveInputComponent::
                Flag::
                    Sprinting
        );

    cameraInput.valid =
        true;

    camera::
        getCameraState().
        input =
            cameraInput;

    /*
     * Suppress physical player only.
     *
     * RawMoveInputComponent tidak disentuh.
     */
    suppressMoveComponent(
        *input
    );

    mPlayer.store(
        player,
        std::memory_order_relaxed
    );

    mEnabled.store(
        true,
        std::memory_order_release
    );

    mIsolationApplied.store(
        true,
        std::memory_order_release
    );

    if (
        !mLoggedInputCapture
    ) {
        mLoggedInputCapture =
            true;

        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Stage-2K PRE input split strafe=%.3f forward=%.3f vertical=%.3f",
            cameraInput.strafe,
            cameraInput.forward,
            cameraInput.vertical
        );
    }

    if (
        rawInput != nullptr

        &&

        !mLoggedRawInput
    ) {
        mLoggedRawInput =
            true;

        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Stage-2K RawMoveInput preserved; sneak HOLD uses press/release latch"
        );
    }

    if (
        !mLoggedSuppression
    ) {
        mLoggedSuppression =
            true;

        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Physical MoveInput suppressed; RawMoveInput preserved"
        );
    }

    return true;
}

bool
PlayerFreezeController::
suppressMovementInput(
    void* player
) noexcept {
    auto*
        input =
            game::
                findComponent<
                    game::MoveInputComponent
                >(
                    player,
                    game::
                        kMoveInputComponentHash
                );

    if (
        input == nullptr
    ) {
        return false;
    }

    suppressMoveComponent(
        *input
    );

    return true;
}

void
PlayerFreezeController::preTick(
    void* player,
    bool active
) noexcept {
    if (
        player == nullptr
    ) {
        return;
    }

    if (
        !active
    ) {
        if (
            mIsolationApplied.load(
                std::memory_order_acquire
            )
        ) {
            __android_log_print(
                ANDROID_LOG_INFO,
                kLogTag,
                "Physical player input isolation released"
            );
        }

        clearSession();

        return;
    }

    void*
        tracked =
            mPlayer.load(
                std::memory_order_relaxed
            );

    if (
        tracked != player

        ||

        !mIsolationApplied.load(
            std::memory_order_acquire
        )
    ) {
        clearSession();

        mPlayer.store(
            player,
            std::memory_order_relaxed
        );

        captureRotation(
            player
        );
    }

    captureInputAndSuppress(
        player
    );

    restoreRotation(
        player
    );
}

void
PlayerFreezeController::postTick(
    void* player,
    bool active
) noexcept {
    if (
        !active

        ||

        player == nullptr
    ) {
        return;
    }

    /*
     * POST normalTick:
     *
     * baca ulang input vertical setelah Minecraft
     * memproses input touch.
     *
     * Jangan overwrite strafe/forward.
     */
    auto*
        input =
            game::
                findComponent<
                    game::MoveInputComponent
                >(
                    player,
                    game::
                        kMoveInputComponentHash
                );

    auto*
        rawInput =
            game::
                findComponent<
                    RawMoveInputComponent
                >(
                    player,
                    kRawMoveInputComponentHash
                );

    if (
        input != nullptr
    ) {
        const game::MoveInputState*
            externalRaw =
                rawInput != nullptr
                    ? &rawInput->mRawInput
                    : nullptr;

        /*
         * Sneak HOLD.
         */
        const bool
            sneakPressed =
                anySneakPressed(
                    *input,
                    externalRaw
                );

        const bool
            sneakReleased =
                anySneakReleased(
                    *input,
                    externalRaw
                );

        const bool
            sneakHeldNow =
                anySneakHeld(
                    *input,
                    externalRaw
                );

        updateSneakHeldState(
            sneakHeldNow,
            sneakPressed,
            sneakReleased,
            mSneakHeld
        );

        /*
         * Jump HOLD.
         */
        const bool
            jumpPressed =
                anyJumpPressed(
                    *input,
                    externalRaw
                );

        const bool
            jumpReleased =
                anyJumpReleased(
                    *input,
                    externalRaw
                );

        const bool
            jumpHeldNow =
                anyJumpHeld(
                    *input,
                    externalRaw
                );

        updateJumpHeldState(
            jumpHeldNow,
            jumpPressed,
            jumpReleased,
            mJumpHeld
        );

        /*
         * Hanya update vertical.
         *
         * Horizontal dari PRE tetap dipakai.
         */
        auto&
            cameraInput =
                camera::
                    getCameraState().
                    input;

        applyVerticalInput(
            cameraInput,
            mJumpHeld,
            mSneakHeld
        );
    }

    /*
     * Setelah kamera membaca input,
     * zero kembali physical player.
     */
    suppressMovementInput(
        player
    );

    restoreRotation(
        player
    );
}

void
PlayerFreezeController::disable()
    noexcept {
    mEnabled.store(
        false,
        std::memory_order_release
    );
}

void
PlayerFreezeController::clearSession()
    noexcept {
    mEnabled.store(
        false,
        std::memory_order_release
    );

    mIsolationApplied.store(
        false,
        std::memory_order_release
    );

    mPlayer.store(
        nullptr,
        std::memory_order_relaxed
    );

    camera::
        getCameraState().
        input =
            {};

    mRotationCaptured =
        false;

    mActorRotationValid =
        false;

    mHeadRotationValid =
        false;

    mBodyRotationValid =
        false;

    mRenderRotationValid =
        false;

    mSneakHeld =
        false;

    mJumpHeld =
        false;

    /*
     * Tetap ada di header untuk compatibility
     * dengan Stage sebelumnya.
     *
     * Stage-2K tidak memakai toggle ini.
     */
    mSneakToggleLast =
        false;

    mLoggedInputCapture =
        false;

    mLoggedSuppression =
        false;

    mLoggedRawInput =
        false;

    mLoggedRotation =
        false;

    mLoggedFailure =
        false;
}

bool
PlayerFreezeController::enabled()
    const noexcept {
    return mEnabled.load(
        std::memory_order_acquire
    );
}

bool
PlayerFreezeController::
nativeIsolationApplied()
    const noexcept {
    return mIsolationApplied.load(
        std::memory_order_acquire
    );
}

bool
PlayerFreezeController::stateCaptured()
    const noexcept {
    return nativeIsolationApplied();
}

void*
PlayerFreezeController::player()
    const noexcept {
    return mPlayer.load(
        std::memory_order_relaxed
    );
}

} // namespace levifreecam
