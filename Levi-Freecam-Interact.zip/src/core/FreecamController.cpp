#include "core/FreecamController.hpp"

#include "core/PlayerFreezeController.hpp"

#include "camera/NativeCameraController.hpp"

#include "render/FirstPersonHook.hpp"

#include <android/log.h>


namespace levifreecam {


namespace {


constexpr char
    kLogTag[] =
        "Levi Freecam";


} // namespace


FreecamController&
FreecamController::instance() {

    static FreecamController
        controller;


    return controller;
}


void
FreecamController::setModuleEnabled(
    bool enabled
) noexcept {

    mModuleEnabled.store(
        enabled,
        std::memory_order_release
    );


    if (
        !enabled
    ) {

        mRequestedActive.store(
            false,
            std::memory_order_release
        );


        /*
         * Restore vanilla rendering before anything else.
         */
        render::
            FirstPersonHook::
            instance().
            setEnabled(
                false
            );


        PlayerFreezeController::
            instance().
            disable();


        restoreNow();


        clearSessionState();
    }
}


void
FreecamController::setActive(
    bool active
) noexcept {

    if (
        active &&
        !moduleEnabled()
    ) {

        return;
    }


    mRequestedActive.store(
        active,
        std::memory_order_release
    );


    if (
        active
    ) {

        /*
         * Stage-2E render policy:
         *
         * body = visible
         * first-person objects = hidden
         */
        render::
            FirstPersonHook::
            instance().
            setEnabled(
                true
            );


        camera::
            NativeCameraController::
            instance().
            enable();


        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Native Freecam Stage-2E active"
        );
    }
    else {

        /*
         * Immediately restore vanilla render predicates.
         */
        render::
            FirstPersonHook::
            instance().
            setEnabled(
                false
            );


        PlayerFreezeController::
            instance().
            disable();


        restoreNow();


        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Native Freecam Stage-2E deactivated"
        );
    }
}


void
FreecamController::onLocalPlayerPreTick(
    void* localPlayer
) noexcept {

    if (
        localPlayer ==
        nullptr
    ) {

        return;
    }


    mCurrentPlayer.store(
        localPlayer,
        std::memory_order_relaxed
    );


    PlayerFreezeController::
        instance().
        preTick(

            localPlayer,

            active()
        );
}


void
FreecamController::onLocalPlayerPostTick(
    void* localPlayer
) noexcept {

    if (
        localPlayer ==
        nullptr
    ) {

        return;
    }


    const bool
        freecamActive =
            active();


    PlayerFreezeController::
        instance().
        postTick(

            localPlayer,

            freecamActive
        );


    if (
        !freecamActive
    ) {

        return;
    }


    /*
     * Current custom integrator remains active for Stage-2E.
     *
     * Native CameraFlyMove will replace this only after the
     * camera-entity correlation pass is runtime-validated.
     */
    camera::
        NativeCameraController::
        instance().
        update();
}


bool
FreecamController::restoreNow()
    noexcept {

    camera::
        NativeCameraController::
        instance().
        disable();


    return true;
}


void
FreecamController::forceDisable()
    noexcept {

    mRequestedActive.store(
        false,
        std::memory_order_release
    );


    mModuleEnabled.store(
        false,
        std::memory_order_release
    );


    /*
     * Restore rendering while hooks still exist.
     */
    render::
        FirstPersonHook::
        instance().
        setEnabled(
            false
        );


    PlayerFreezeController::
        instance().
        disable();


    restoreNow();


    clearSessionState();


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,
        "Freecam force-disabled"
    );
}


void
FreecamController::clearSessionState()
    noexcept {

    mCurrentPlayer.store(
        nullptr,
        std::memory_order_relaxed
    );
}


void
FreecamController::notePlayerAuthInput()
    noexcept {

    mPlayerAuthInputSeen.fetch_add(
        1,
        std::memory_order_relaxed
    );
}


bool
FreecamController::moduleEnabled()
    const noexcept {

    return
        mModuleEnabled.load(
            std::memory_order_acquire
        );
}


bool
FreecamController::active()
    const noexcept {

    return
        mRequestedActive.load(
            std::memory_order_acquire
        );
}


bool
FreecamController::cameraActive()
    const noexcept {

    return

        camera::
            NativeCameraController::
            instance().
            isEnabled();
}


bool
FreecamController::
shouldSuppressPlayerAuthInput()
    const noexcept {

    return
        active();
}


std::uint64_t
FreecamController::playerAuthInputSeen()
    const noexcept {

    return
        mPlayerAuthInputSeen.load(
            std::memory_order_relaxed
        );
}


} // namespace levifreecam
