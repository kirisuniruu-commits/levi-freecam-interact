#pragma once

#include <atomic>
#include <cstdint>


namespace levifreecam {


class FreecamController final {

public:

    static FreecamController&
    instance();


    /*
     * Main Levi Mod Menu module state.
     */
    void setModuleEnabled(
        bool enabled
    ) noexcept;


    /*
     * CAM HUD toggle state.
     */
    void setActive(
        bool active
    ) noexcept;


    /*
     * Called immediately BEFORE
     * LocalPlayer::normalTick.
     *
     * Stage-2C:
     *
     * - capture real MoveInputComponent;
     * - preserve input for camera;
     * - suppress movement input for physical player.
     */
    void onLocalPlayerPreTick(
        void* localPlayer
    ) noexcept;


    /*
     * Called immediately AFTER
     * LocalPlayer::normalTick.
     *
     * Stage-2C:
     *
     * - suppress movement reconstructed by vanilla;
     * - update independent camera from captured input.
     */
    void onLocalPlayerPostTick(
        void* localPlayer
    ) noexcept;


    /*
     * Restore camera state.
     */
    bool restoreNow()
        noexcept;


    /*
     * Force complete Freecam shutdown.
     */
    void forceDisable()
        noexcept;


    /*
     * Diagnostic PlayerAuthInput counter.
     */
    void notePlayerAuthInput()
        noexcept;


    [[nodiscard]]
    bool moduleEnabled()
        const noexcept;


    [[nodiscard]]
    bool active()
        const noexcept;


    [[nodiscard]]
    bool cameraActive()
        const noexcept;


    /*
     * Temporary Stage-2C network isolation.
     *
     * Packet suppression remains active while CAM is ON
     * until native player isolation is completely finalized.
     */
    [[nodiscard]]
    bool shouldSuppressPlayerAuthInput()
        const noexcept;


    [[nodiscard]]
    std::uint64_t
    playerAuthInputSeen()
        const noexcept;


private:

    FreecamController()
        = default;


    void clearSessionState()
        noexcept;


private:

    /*
     * Main module state.
     */
    std::atomic_bool
        mModuleEnabled{
            false
        };


    /*
     * CAM toggle state.
     */
    std::atomic_bool
        mRequestedActive{
            false
        };


    /*
     * Current LocalPlayer from normalTick.
     */
    std::atomic<void*>
        mCurrentPlayer{
            nullptr
        };


    /*
     * PlayerAuthInput diagnostic counter.
     */
    std::atomic_uint64_t
        mPlayerAuthInputSeen{
            0
        };
};


} // namespace levifreecam
