#include "FreecamMod.hpp"

#include "core/FreecamController.hpp"

#include "camera/CameraHook.hpp"
#include "camera/CameraSystemHook.hpp"

#include "render/FirstPersonHook.hpp"

#include <android/log.h>

#include <pl/Mod.hpp>


namespace levifreecam {


namespace {


constexpr char
    kLogTag[] =
        "Levi Freecam";


} // namespace


FreecamMod&
FreecamMod::instance() {

    static
    FreecamMod
        mod;


    return mod;
}


FreecamMod::FreecamMod()

    : mSelf(
        *pl::mod::
            NativeMod::
            current()
    ) {
}


ll::mod::NativeMod&
FreecamMod::getSelf()
    const noexcept {

    return
        mSelf;
}


bool
FreecamMod::load() {

    getSelf().
        getLogger().
        info(
            "Loading Levi Freecam Native v0.6.2 Stage-2F"
        );


    return true;
}


bool
FreecamMod::enable() {

    auto&
        self =
            getSelf();


    /*
     * =========================================================
     * 1. Stage-2D LocalPlayer + native MoveRequest hooks
     * =========================================================
     */
    if (
        !mPlayerHook.install()
    ) {

        self.
            getLogger().
            error(
                "Failed install Player hook"
            );


        return false;
    }


    self.
        getLogger().
        info(

            "Player hook installed 0x{:x}",

            mPlayerHook.
                targetAddress()
        );


    /*
     * =========================================================
     * 2. Packet isolation
     * =========================================================
     */
    if (
        !mPacketHook.install()
    ) {

        self.
            getLogger().
            error(
                "Failed install Packet hook"
            );


        mPlayerHook.
            uninstall();


        return false;
    }


    self.
        getLogger().
        info(

            "Packet hook installed 0x{:x}",

            mPacketHook.
                targetAddress()
        );


    /*
     * =========================================================
     * 3. Active camera transform
     * =========================================================
     */
    if (
        !camera::
            installCameraHook()
    ) {

        self.
            getLogger().
            error(
                "Camera hook failed"
            );


        mPacketHook.
            uninstall();


        mPlayerHook.
            uninstall();


        return false;
    }


    self.
        getLogger().
        info(

            "Camera hook installed 0x{:x}",

            camera::
                cameraHookTargetAddress()
        );


    /*
     * =========================================================
     * 4. Stage-2F UpdatePlayerFromCamera isolation
     * =========================================================
     *
     * This is NOT the old generic CameraSystem signature.
     *
     * New exact target:
     *
     *     UpdatePlayerFromCamera single-entity body
     *
     *     RVA 0x82FEF5C
     *
     * During CAM:
     *
     *     camera rotation remains independent
     *     player head/body rotation is not updated from camera
     */
    if (
        !camera::
            installCameraSystemHook()
    ) {

        self.
            getLogger().
            error(
                "UpdatePlayerFromCamera hook failed"
            );


        camera::
            removeCameraHook();


        mPacketHook.
            uninstall();


        mPlayerHook.
            uninstall();


        return false;
    }


    self.
        getLogger().
        info(

            "UpdatePlayerFromCamera hook installed 0x{:x}",

            camera::
                cameraSystemAddress()
        );


    /*
     * =========================================================
     * 5. Stage-2E render predicates
     * =========================================================
     *
     * body = show
     *
     * first-person objects = hide
     */
    if (
        !render::
            FirstPersonHook::
            instance().
            install()
    ) {

        self.
            getLogger().
            error(
                "Stage-2E render predicate hooks failed"
            );


        camera::
            removeCameraSystemHook();


        camera::
            removeCameraHook();


        mPacketHook.
            uninstall();


        mPlayerHook.
            uninstall();


        return false;
    }


    self.
        getLogger().
        info(

            "Render predicates installed body=0x{:x} firstPerson=0x{:x}",

            render::
                FirstPersonHook::
                bodyTargetAddress(),

            render::
                FirstPersonHook::
                firstPersonTargetAddress()
        );


    /*
     * =========================================================
     * 6. Levi Mod Menu
     * =========================================================
     */
    const bool
        registered =

            mModMenu.
                registerAll(

                    self.
                        getId(),

                    [this](
                        bool enabled
                    ) {

                        setModuleEnabled(
                            enabled
                        );
                    },

                    [this](
                        bool active
                    ) {

                        setCameraActive(
                            active
                        );
                    }
                );


    if (
        !registered
    ) {

        self.
            getLogger().
            error(
                "Failed register ModMenu"
            );


        render::
            FirstPersonHook::
            instance().
            uninstall();


        camera::
            removeCameraSystemHook();


        camera::
            removeCameraHook();


        mPacketHook.
            uninstall();


        mPlayerHook.
            uninstall();


        return false;
    }


    self.
        getLogger().
        info(
            "Levi Freecam v0.6.2 Stage-2F ready"
        );


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,
        "Stage-2F profile: MoveRequest freeze + player-rotation detach + render predicates"
    );


    return true;
}


bool
FreecamMod::disable() {

    /*
     * Make CAM inactive and restore vanilla state while all
     * hooks still exist.
     */
    restoreAndReset();


    /*
     * No more UI callbacks after this point.
     */
    mModMenu.
        unregisterAll();


    /*
     * Return camera rendering to vanilla.
     */
    render::
        FirstPersonHook::
        instance().
        uninstall();


    /*
     * Restore UpdatePlayerFromCamera before removing the
     * ordinary camera transform hook.
     */
    camera::
        removeCameraSystemHook();


    camera::
        removeCameraHook();


    mPacketHook.
        uninstall();


    mPlayerHook.
        uninstall();


    getSelf().
        getLogger().
        info(
            "Levi Freecam disabled"
        );


    return true;
}


bool
FreecamMod::unload() {

    restoreAndReset();


    mModMenu.
        unregisterAll();


    render::
        FirstPersonHook::
        instance().
        uninstall();


    camera::
        removeCameraSystemHook();


    camera::
        removeCameraHook();


    mPacketHook.
        uninstall();


    mPlayerHook.
        uninstall();


    getSelf().
        getLogger().
        info(
            "Levi Freecam unloaded"
        );


    return true;
}


void
FreecamMod::setModuleEnabled(
    bool enabled
) {

    FreecamController::
        instance().
        setModuleEnabled(
            enabled
        );


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,

        "Freecam module %s",

        enabled
            ? "ON"
            : "OFF"
    );
}


void
FreecamMod::setCameraActive(
    bool active
) {

    FreecamController::
        instance().
        setActive(
            active
        );


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,

        "Camera %s",

        active
            ? "ON"
            : "OFF"
    );
}


void
FreecamMod::restoreAndReset() {

    FreecamController::
        instance().
        forceDisable();
}


} // namespace levifreecam


PL_REGISTER_MOD(
    levifreecam::FreecamMod,
    levifreecam::FreecamMod::instance()
)
