#pragma once

#include <cstddef>
#include <cstdint>
#include <cstring>


namespace levifreecam::game {


/*
 * ============================================================
 * Component hashes
 *
 * Confirmed against the exact Android libminecraftpe.so:
 *
 * Build ID:
 * b480c79a54f33d6e4f0d63a131673e3daf749911
 * ============================================================
 */

inline constexpr std::uint32_t
    kMoveInputComponentHash =
        0x018B1887U;


inline constexpr std::uint32_t
    kMoveRequestComponentHash =
        0x4C8F7288U;


inline constexpr std::uint32_t
    kStateVectorComponentHash =
        0x1B5D5238U;


/*
 * Actor contains inline EntityContext beginning at +0x08.
 *
 * Therefore:
 *
 * Actor +0x10 = EnTT registry pointer
 * Actor +0x18 = EntityId
 *
 * IMPORTANT:
 *
 * We never call EnTT from this module.
 * We only mirror Minecraft's raw storage lookup.
 */

inline constexpr std::size_t
    kActorRegistryOffset =
        0x10;


inline constexpr std::size_t
    kActorEntityIdOffset =
        0x18;


/*
 * ============================================================
 * Basic math layouts
 * ============================================================
 */

struct Vec2 final {

    float x{
        0.0f
    };


    float y{
        0.0f
    };
};


struct Vec3 final {

    float x{
        0.0f
    };


    float y{
        0.0f
    };


    float z{
        0.0f
    };
};


static_assert(
    sizeof(Vec2) ==
        0x08
);


static_assert(
    sizeof(Vec3) ==
        0x0C
);


/*
 * ============================================================
 * MoveInputState
 * ============================================================
 */

struct MoveInputState final {

    enum class Flag :
        std::uint32_t {

        SneakDown               = 0,
        SneakToggleDown         = 1,

        WantDownSlow            = 2,
        WantUpSlow              = 3,

        BlockSelectDown         = 4,

        AscendBlock             = 5,
        DescendBlock            = 6,

        JumpDown                = 7,
        SprintDown              = 8,

        UpLeft                  = 9,
        UpRight                 = 10,

        DownLeft                = 11,
        DownRight               = 12,

        Up                      = 13,
        Down                    = 14,

        Left                    = 15,
        Right                   = 16,

        Ascend                  = 17,
        Descend                 = 18,

        ChangeHeight            = 19,

        LookCenter              = 20,

        SneakInputCurrentlyDown = 21,
        SneakInputWasReleased   = 22,
        SneakInputWasPressed    = 23,

        JumpInputWasReleased    = 24,
        JumpInputWasPressed     = 25,
        JumpInputCurrentlyDown  = 26
    };


    std::uint32_t
        mFlagValues{
            0
        };


    Vec2
        mAnalogMoveVector{};


    std::uint8_t
        mLookSlightDirField{
            0
        };


    std::uint8_t
        mLookNormalDirField{
            0
        };


    std::uint8_t
        mLookSmoothDirField{
            0
        };


    std::uint8_t
        mPadding{
            0
        };


    [[nodiscard]]
    bool checkFlag(
        Flag flag
    ) const noexcept {

        const auto bit =
            static_cast<
                std::uint32_t
            >(
                flag
            );


        if (
            bit >= 32
        ) {

            return false;
        }


        return (
            mFlagValues &
            (
                std::uint32_t{1}
                <<
                bit
            )
        ) != 0;
    }
};


static_assert(
    sizeof(
        MoveInputState
    ) == 0x10
);


/*
 * ============================================================
 * MoveInputComponent
 *
 * Exact size:
 *
 *     0x64
 *
 * Minecraft itself uses 0x64 as component stride.
 * ============================================================
 */

struct MoveInputComponent final {

    enum class Flag :
        std::uint16_t {

        Sneaking                        = 0,
        Sprinting                       = 1,

        WantUp                          = 2,
        WantDown                        = 3,

        Jumping                         = 4,

        AutoJumpingInWater              = 5,

        MoveInputStateLocked            = 6,

        PersistSneak                    = 7,
        AutoJumpEnabled                 = 8,

        IsCameraRelativeMovementEnabled = 9,

        IsRotControlledByMoveDirection  = 10
    };


    MoveInputState
        mInputState{};


    MoveInputState
        mRawInputState{};


    std::uint8_t
        mHoldAutoJumpInWaterTicks{
            0
        };


    std::uint8_t
        mPadding0[3]{
            0,
            0,
            0
        };


    /*
     * Processed horizontal player movement.
     *
     * Minecraft touch input convention:
     *
     * X:
     *   + = right
     *   - = left
     *
     * Y:
     *   - = forward
     *   + = backward
     */
    Vec2
        mMove{};


    Vec2
        mLookDelta{};


    Vec2
        mInteractDir{};


    Vec3
        mDisplacement{};


    Vec3
        mDisplacementDelta{};


    Vec3
        mCameraOrientation{};


    std::uint16_t
        mFlagValues{
            0
        };


    bool
        mIsPaddling[2]{
            false,
            false
        };


    [[nodiscard]]
    bool checkFlag(
        Flag flag
    ) const noexcept {

        const auto bit =
            static_cast<
                std::uint16_t
            >(
                flag
            );


        if (
            bit >= 16
        ) {

            return false;
        }


        return (
            mFlagValues &
            (
                std::uint16_t{1}
                <<
                bit
            )
        ) != 0;
    }
};


static_assert(
    sizeof(
        MoveInputComponent
    ) == 0x64
);


static_assert(
    offsetof(
        MoveInputComponent,
        mInputState
    ) == 0x00
);


static_assert(
    offsetof(
        MoveInputComponent,
        mRawInputState
    ) == 0x10
);


static_assert(
    offsetof(
        MoveInputComponent,
        mMove
    ) == 0x24
);


static_assert(
    offsetof(
        MoveInputComponent,
        mLookDelta
    ) == 0x2C
);


static_assert(
    offsetof(
        MoveInputComponent,
        mInteractDir
    ) == 0x34
);


static_assert(
    offsetof(
        MoveInputComponent,
        mDisplacement
    ) == 0x3C
);


static_assert(
    offsetof(
        MoveInputComponent,
        mDisplacementDelta
    ) == 0x48
);


static_assert(
    offsetof(
        MoveInputComponent,
        mCameraOrientation
    ) == 0x54
);


static_assert(
    offsetof(
        MoveInputComponent,
        mFlagValues
    ) == 0x60
);


/*
 * ============================================================
 * StateVectorComponent
 *
 * Native stride:
 *
 *     0x24
 *
 * +0x00 Vec3 position
 * +0x0C Vec3 previous position
 * +0x18 Vec3 movement delta
 * ============================================================
 */

struct StateVectorComponent final {

    Vec3
        mPos{};


    Vec3
        mPosPrev{};


    Vec3
        mPosDelta{};
};


static_assert(
    sizeof(
        StateVectorComponent
    ) == 0x24
);


static_assert(
    offsetof(
        StateVectorComponent,
        mPos
    ) == 0x00
);


static_assert(
    offsetof(
        StateVectorComponent,
        mPosPrev
    ) == 0x0C
);


static_assert(
    offsetof(
        StateVectorComponent,
        mPosDelta
    ) == 0x18
);


/*
 * ============================================================
 * MoveRequestComponent
 *
 * Native debug-camera system uses:
 *
 *     stride = 0x98
 *
 * Header layout gives:
 *
 * +0x30 Vec3 mPreCollisionSpeed
 * +0x3C Vec3 mSpeed
 * ============================================================
 */

struct MoveRequestComponent final {

    std::byte
        mOriginalShapes[
            0x30
        ]{};


    Vec3
        mPreCollisionSpeed{};


    Vec3
        mSpeed{};


    Vec3
        mMaxDepenetration{};


    bool
        mIsPenetrating{
            false
        };


    bool
        mSneaking{
            false
        };


    std::byte
        mRemaining[
            0x98 -
            0x56
        ]{};
};


static_assert(
    sizeof(
        MoveRequestComponent
    ) == 0x98
);


static_assert(
    offsetof(
        MoveRequestComponent,
        mPreCollisionSpeed
    ) == 0x30
);


static_assert(
    offsetof(
        MoveRequestComponent,
        mSpeed
    ) == 0x3C
);


/*
 * ============================================================
 * Safe raw access helpers
 * ============================================================
 */

template <
    typename T
>
[[nodiscard]]
inline
T readValue(
    const void* base,
    std::size_t offset
) noexcept {

    T result{};


    if (
        base ==
        nullptr
    ) {

        return result;
    }


    const auto*
        source =

            reinterpret_cast<
                const std::byte*
            >(
                base
            )

            +

            offset;


    std::memcpy(
        &result,
        source,
        sizeof(T)
    );


    return result;
}


[[nodiscard]]
inline
bool pointerLooksUsable(
    const void* pointer
) noexcept {

    if (
        pointer ==
        nullptr
    ) {

        return false;
    }


    /*
     * Android heap pointers can contain a top-byte memory tag.
     *
     * Do not strip/reject it.
     */
    const auto raw =
        reinterpret_cast<
            std::uintptr_t
        >(
            pointer
        );


    return
        raw >=
        0x10000;
}


/*
 * ============================================================
 * Find component storage by EnTT type hash.
 *
 * IMPORTANT:
 *
 * This only READS Minecraft's registry structures.
 *
 * It does NOT call:
 *
 *     entt::get
 *     entt::emplace
 *     entt::remove
 *     entt::all_of
 *
 * or any other foreign EnTT ABI method.
 * ============================================================
 */

[[nodiscard]]
inline
void*
findStorage(
    void* registry,
    std::uint32_t typeHash
) noexcept {

    if (
        !pointerLooksUsable(
            registry
        )
    ) {

        return nullptr;
    }


    void*
        bucketBegin =
            readValue<void*>(
                registry,
                0x38
            );


    void*
        bucketEnd =
            readValue<void*>(
                registry,
                0x40
            );


    void*
        nodeBase =
            readValue<void*>(
                registry,
                0x50
            );


    if (
        !pointerLooksUsable(
            bucketBegin
        )

        ||

        !pointerLooksUsable(
            bucketEnd
        )

        ||

        !pointerLooksUsable(
            nodeBase
        )
    ) {

        return nullptr;
    }


    const auto begin =
        reinterpret_cast<
            std::uintptr_t
        >(
            bucketBegin
        );


    const auto end =
        reinterpret_cast<
            std::uintptr_t
        >(
            bucketEnd
        );


    if (
        end <= begin
    ) {

        return nullptr;
    }


    const std::size_t
        bucketCount =

            (
                end -
                begin
            )

            /

            sizeof(
                std::uint64_t
            );


    if (
        bucketCount ==
        0
    ) {

        return nullptr;
    }


    const std::size_t
        bucketIndex =

            static_cast<
                std::size_t
            >(
                typeHash
            )

            &

            (
                bucketCount -
                1
            );


    std::uint64_t
        nodeIndex =

            readValue<
                std::uint64_t
            >(
                bucketBegin,

                bucketIndex *
                    sizeof(
                        std::uint64_t
                    )
            );


    constexpr
    std::uint64_t
        kNoNode =
            UINT64_MAX;


    std::size_t
        guard =
            0;


    while (
        nodeIndex !=
            kNoNode

        &&

        guard <
            4096
    ) {

        ++guard;


        auto*
            node =

                reinterpret_cast<
                    std::byte*
                >(
                    nodeBase
                )

                +

                nodeIndex *
                    0x20;


        const auto
            currentHash =

                readValue<
                    std::uint32_t
                >(
                    node,
                    0x08
                );


        if (
            currentHash ==
            typeHash
        ) {

            return
                readValue<void*>(
                    node,
                    0x10
                );
        }


        nodeIndex =
            readValue<
                std::uint64_t
            >(
                node,
                0x00
            );
    }


    return nullptr;
}


/*
 * ============================================================
 * Find existing entity component.
 *
 * This mirrors the native ARM64 storage traversal.
 *
 * CRITICAL CORRECTION FROM v0.6.2 INITIAL STAGE-2B:
 *
 * OLD / WRONG:
 *
 *     densePage
 *       + 0x10
 *       + denseSlot * componentSize
 *
 * NATIVE / CORRECT:
 *
 *     densePage
 *       + denseSlot * componentSize
 *
 * There is NO +0x10.
 * ============================================================
 */

[[nodiscard]]
inline
void*
findComponent(
    void* actor,
    std::uint32_t typeHash,
    std::size_t componentSize
) noexcept {

    if (
        !pointerLooksUsable(
            actor
        )

        ||

        componentSize ==
        0
    ) {

        return nullptr;
    }


    void*
        registry =
            readValue<void*>(
                actor,
                kActorRegistryOffset
            );


    if (
        !pointerLooksUsable(
            registry
        )
    ) {

        return nullptr;
    }


    const std::uint32_t
        entity =
            readValue<
                std::uint32_t
            >(
                actor,
                kActorEntityIdOffset
            );


    void*
        storage =
            findStorage(
                registry,
                typeHash
            );


    if (
        !pointerLooksUsable(
            storage
        )
    ) {

        return nullptr;
    }


    /*
     * Sparse page pointer vector.
     */
    void*
        sparseBegin =
            readValue<void*>(
                storage,
                0x08
            );


    void*
        sparseEnd =
            readValue<void*>(
                storage,
                0x10
            );


    if (
        !pointerLooksUsable(
            sparseBegin
        )

        ||

        !pointerLooksUsable(
            sparseEnd
        )
    ) {

        return nullptr;
    }


    const auto sparseBeginRaw =
        reinterpret_cast<
            std::uintptr_t
        >(
            sparseBegin
        );


    const auto sparseEndRaw =
        reinterpret_cast<
            std::uintptr_t
        >(
            sparseEnd
        );


    if (
        sparseEndRaw <
        sparseBeginRaw
    ) {

        return nullptr;
    }


    const std::size_t
        sparsePageCount =

            (
                sparseEndRaw -
                sparseBeginRaw
            )

            /

            sizeof(void*);


    /*
     * EntityId:
     *
     * bits 11..17 select sparse page.
     */
    const std::size_t
        sparsePageIndex =

            (
                entity >>
                11
            )

            &

            0x7FU;


    if (
        sparsePageIndex >=
        sparsePageCount
    ) {

        return nullptr;
    }


    void*
        sparsePage =
            readValue<void*>(
                sparseBegin,

                sparsePageIndex *
                    sizeof(void*)
            );


    if (
        !pointerLooksUsable(
            sparsePage
        )
    ) {

        return nullptr;
    }


    const std::size_t
        sparseSlot =

            entity &
            0x7FFU;


    const std::uint32_t
        packedEntry =

            readValue<
                std::uint32_t
            >(
                sparsePage,

                sparseSlot *
                    sizeof(
                        std::uint32_t
                    )
            );


    const std::uint32_t
        expectedVersion =

            entity &
            0xFFFC0000U;


    const std::uint32_t
        versionCheck =

            packedEntry ^
            expectedVersion;


    /*
     * Exact native validity comparison.
     */
    if (
        versionCheck >
        0x3FFFEU
    ) {

        return nullptr;
    }


    const std::uint32_t
        denseIndex =

            packedEntry &
            0x3FFFFU;


    void*
        densePages =
            readValue<void*>(
                storage,
                0x50
            );


    if (
        !pointerLooksUsable(
            densePages
        )
    ) {

        return nullptr;
    }


    /*
     * 128 components per dense page.
     */
    const std::size_t
        densePageIndex =

            denseIndex >>
            7;


    const std::size_t
        denseSlot =

            denseIndex &
            0x7FU;


    void*
        densePage =
            readValue<void*>(
                densePages,

                densePageIndex *
                    sizeof(void*)
            );


    if (
        !pointerLooksUsable(
            densePage
        )
    ) {

        return nullptr;
    }


    /*
     * CRITICAL:
     *
     * NO +0x10.
     *
     * This now matches Minecraft's own ARM64 code:
     *
     *     umaddl component,
     *            slot,
     *            componentSize,
     *            densePage
     */
    return

        reinterpret_cast<
            std::byte*
        >(
            densePage
        )

        +

        denseSlot *
            componentSize;
}


template <
    typename T
>
[[nodiscard]]
inline
T*
findComponent(
    void* actor,
    std::uint32_t typeHash
) noexcept {

    return
        reinterpret_cast<T*>(
            findComponent(
                actor,
                typeHash,
                sizeof(T)
            )
        );
}


} // namespace levifreecam::game
