#pragma once

#include <entt/entt.hpp>

#include <cstddef>
#include <cstdint>


/*
 * ============================================================
 * Minecraft EntityId
 * ============================================================
 */

class EntityId;


struct EntityIdTraits {

    using value_type =
        EntityId;

    using entity_type =
        std::uint32_t;

    using version_type =
        std::uint16_t;


    static constexpr
    entity_type
        entity_mask =
            0x3FFFF;


    static constexpr
    entity_type
        version_mask =
            0x3FFF;
};


namespace entt {

template <>
class entt_traits<::EntityId>
    : public basic_entt_traits<
        ::EntityIdTraits
    > {

public:

    static constexpr
    entity_type
        page_size =
            ENTT_SPARSE_PAGE;
};

} // namespace entt


class EntityId
    : public entt::entt_traits<
        EntityId
    > {

public:

    entity_type
        mRawId{
            entt::null
        };


    constexpr
    EntityId()
        = default;


    constexpr
    EntityId(
        entity_type rawId
    ) noexcept
        : mRawId(
            rawId
        ) {
    }


    constexpr
    operator entity_type()
        const noexcept {

        return mRawId;
    }
};


static_assert(
    sizeof(EntityId) == 4,
    "Unexpected EntityId size"
);


/*
 * ============================================================
 * Basic vector layouts
 * ============================================================
 */

struct LFMoveVec2 {

    float x{
        0.0f
    };

    float y{
        0.0f
    };
};


struct LFMoveVec3 {

    float x{
        0.0f
    };

    float y{
        0.0f
    };

    float z{
        0.0f
    };
};


/*
 * ============================================================
 * MoveInputState
 * ============================================================
 */

struct MoveInputState {

    enum class Flag : int {

        SneakDown               = 0,
        SneakToggleDown         = 1,

        WantDownSlow            = 2,
        WantUpSlow              = 3,

        BlockSelectDown         = 4,

        AscendBlock             = 5,
        DescendBlock            = 6,

        JumpDown                = 7,
        SprintDown              = 8,

        UpLeft                  = 9,
        UpRight                 = 10,

        DownLeft                = 11,
        DownRight               = 12,

        Up                      = 13,
        Down                    = 14,

        Left                    = 15,
        Right                   = 16,

        Ascend                  = 17,
        Descend                 = 18,

        ChangeHeight            = 19,

        LookCenter              = 20,

        SneakInputCurrentlyDown = 21,
        SneakInputWasReleased   = 22,
        SneakInputWasPressed    = 23,

        JumpInputWasReleased    = 24,
        JumpInputWasPressed     = 25,
        JumpInputCurrentlyDown  = 26,

        Count                   = 27
    };


    std::uint32_t
        mFlagValues{
            0
        };


    LFMoveVec2
        mAnalogMoveVector{};


    std::uint8_t
        mLookSlightDirField{
            0
        };


    std::uint8_t
        mLookNormalDirField{
            0
        };


    std::uint8_t
        mLookSmoothDirField{
            0
        };


    std::uint8_t
        mPadding{
            0
        };


    [[nodiscard]]
    bool checkFlag(
        Flag flag
    ) const noexcept {

        const auto bit =
            static_cast<
                std::uint32_t
            >(
                flag
            );


        if (
            bit >= 32
        ) {

            return false;
        }


        return (
            mFlagValues &
            (
                std::uint32_t{1}
                <<
                bit
            )
        ) != 0;
    }
};


static_assert(
    sizeof(MoveInputState) ==
        0x10,
    "Unexpected MoveInputState size"
);


/*
 * ============================================================
 * MoveInputComponent
 * ============================================================
 *
 * Confirmed layout:
 *
 * +0x00 input state
 * +0x10 raw input state
 * +0x20 hold auto-jump
 * +0x24 move
 * +0x2C look delta
 * +0x34 interact dir
 * +0x3C displacement
 * +0x48 displacement delta
 * +0x54 camera orientation
 * +0x60 flags
 * +0x62 paddling
 *
 * sizeof = 0x64
 */

struct MoveInputComponent {

    enum class Flag : int {

        Sneaking                        = 0,
        Sprinting                       = 1,

        WantUp                          = 2,
        WantDown                        = 3,

        Jumping                         = 4,

        AutoJumpingInWater              = 5,

        MoveInputStateLocked            = 6,

        PersistSneak                    = 7,
        AutoJumpEnabled                 = 8,

        IsCameraRelativeMovementEnabled = 9,

        IsRotControlledByMoveDirection  = 10,

        Count                           = 11
    };


    MoveInputState
        mInputState{};


    MoveInputState
        mRawInputState{};


    std::uint8_t
        mHoldAutoJumpInWaterTicks{
            0
        };


    std::uint8_t
        mPadding0[3]{
            0,
            0,
            0
        };


    LFMoveVec2
        mMove{};


    LFMoveVec2
        mLookDelta{};


    LFMoveVec2
        mInteractDir{};


    LFMoveVec3
        mDisplacement{};


    LFMoveVec3
        mDisplacementDelta{};


    LFMoveVec3
        mCameraOrientation{};


    std::uint16_t
        mFlagValues{
            0
        };


    bool
        mIsPaddling[2]{
            false,
            false
        };


    [[nodiscard]]
    bool checkFlag(
        Flag flag
    ) const noexcept {

        const auto bit =
            static_cast<
                std::uint16_t
            >(
                flag
            );


        if (
            bit >= 16
        ) {

            return false;
        }


        return (
            mFlagValues &
            (
                std::uint16_t{1}
                <<
                bit
            )
        ) != 0;
    }
};


static_assert(
    alignof(
        MoveInputComponent
    ) == 4,
    "Unexpected MoveInputComponent alignment"
);


static_assert(
    sizeof(
        MoveInputComponent
    ) == 0x64,
    "Unexpected MoveInputComponent size"
);


static_assert(
    offsetof(
        MoveInputComponent,
        mRawInputState
    ) == 0x10
);


static_assert(
    offsetof(
        MoveInputComponent,
        mMove
    ) == 0x24
);


static_assert(
    offsetof(
        MoveInputComponent,
        mLookDelta
    ) == 0x2C
);


static_assert(
    offsetof(
        MoveInputComponent,
        mDisplacement
    ) == 0x3C
);


static_assert(
    offsetof(
        MoveInputComponent,
        mCameraOrientation
    ) == 0x54
);


static_assert(
    offsetof(
        MoveInputComponent,
        mFlagValues
    ) == 0x60
);


/*
 * ============================================================
 * Movement suppression tags
 * ============================================================
 *
 * These are intentionally EMPTY.
 *
 * EnTT may optimize empty/tag components so emplace /
 * get_or_emplace does not necessarily return a T&.
 *
 * Because of that, NEVER take the address of the result of
 * emplace/get_or_emplace for these components.
 */

struct SkipMobTravelComponent {
};


struct PermanentSkipMobTravelComponent {
};


static_assert(
    sizeof(
        SkipMobTravelComponent
    ) == 1
);


static_assert(
    sizeof(
        PermanentSkipMobTravelComponent
    ) == 1
);


/*
 * ============================================================
 * CameraFlyMoveComponent
 * ============================================================
 */

namespace MinecraftCamera {


struct CameraFlyMoveComponent {

    float
        mSpeed{
            0.0f
        };


    float
        mSprintSpeed{
            0.0f
        };
};


static_assert(
    sizeof(
        CameraFlyMoveComponent
    ) == 8
);


} // namespace MinecraftCamera


/*
 * ============================================================
 * EntityContext overlay
 * ============================================================
 */

namespace levifreecam::game {


inline constexpr
std::size_t
    kActorEntityContextOffset =
        0x8;


/*
 * Minecraft layout:
 *
 * +0x00 EntityRegistry&
 * +0x08 entt::basic_registry<EntityId>&
 * +0x10 EntityId
 */
struct EntityContextView {

    void*
        mRegistry{
            nullptr
        };


    entt::basic_registry<
        EntityId
    >*
        mEnTTRegistry{
            nullptr
        };


    EntityId
        mEntity{};


    /*
     * --------------------------------------------------------
     * Basic validation
     * --------------------------------------------------------
     */
    [[nodiscard]]
    bool valid()
        const noexcept {

        if (
            mEnTTRegistry ==
            nullptr
        ) {

            return false;
        }


        const auto registryAddress =
            reinterpret_cast<
                std::uintptr_t
            >(
                mEnTTRegistry
            );


        if (
            registryAddress <
            0x10000
        ) {

            return false;
        }


        return
            mEnTTRegistry->
                valid(
                    mEntity
                );
    }


    /*
     * --------------------------------------------------------
     * Get component pointer
     *
     * Use ONLY for non-empty components such as:
     *
     *     MoveInputComponent
     * --------------------------------------------------------
     */
    template <
        typename T
    >
    [[nodiscard]]
    T*
    tryGet()
        noexcept {

        if (
            !valid()
        ) {

            return nullptr;
        }


        return
            mEnTTRegistry->
                template try_get<T>(
                    mEntity
                );
    }


    /*
     * --------------------------------------------------------
     * Component presence
     * --------------------------------------------------------
     */
    template <
        typename T
    >
    [[nodiscard]]
    bool has()
        const noexcept {

        if (
            !valid()
        ) {

            return false;
        }


        return
            mEnTTRegistry->
                template all_of<T>(
                    mEntity
                );
    }


    /*
     * --------------------------------------------------------
     * Ensure component exists.
     *
     * IMPORTANT FIX:
     *
     * Previously:
     *
     *     return &registry.get_or_emplace<T>(entity);
     *
     * That is invalid for optimized empty/tag components
     * because EnTT may return void.
     *
     * Now we ignore emplace's return value and verify the
     * component using all_of<T>() afterwards.
     * --------------------------------------------------------
     */
    template <
        typename T
    >
    [[nodiscard]]
    bool ensure()
        noexcept {

        if (
            !valid()
        ) {

            return false;
        }


        if (
            mEnTTRegistry->
                template all_of<T>(
                    mEntity
                )
        ) {

            return true;
        }


        /*
         * Intentionally ignore return value.
         *
         * This works for both ordinary and empty/tag
         * components.
         */
        mEnTTRegistry->
            template emplace<T>(
                mEntity
            );


        return
            mEnTTRegistry->
                template all_of<T>(
                    mEntity
                );
    }


    /*
     * --------------------------------------------------------
     * Remove component
     * --------------------------------------------------------
     */
    template <
        typename T
    >
    bool remove()
        noexcept {

        if (
            !valid()
        ) {

            return false;
        }


        if (
            !mEnTTRegistry->
                template all_of<T>(
                    mEntity
                )
        ) {

            return true;
        }


        mEnTTRegistry->
            template remove<T>(
                mEntity
            );


        return
            !mEnTTRegistry->
                template all_of<T>(
                    mEntity
                );
    }
};


static_assert(
    offsetof(
        EntityContextView,
        mRegistry
    ) == 0x0
);


static_assert(
    offsetof(
        EntityContextView,
        mEnTTRegistry
    ) == 0x8
);


static_assert(
    offsetof(
        EntityContextView,
        mEntity
    ) == 0x10
);


/*
 * ============================================================
 * Actor -> EntityContext
 * ============================================================
 */

[[nodiscard]]
inline
EntityContextView*
entityContextFromActor(
    void* actor
) noexcept {

    if (
        actor ==
        nullptr
    ) {

        return nullptr;
    }


    const auto actorAddress =
        reinterpret_cast<
            std::uintptr_t
        >(
            actor
        );


    if (
        actorAddress <
        0x10000
    ) {

        return nullptr;
    }


    return
        reinterpret_cast<
            EntityContextView*
        >(
            actorAddress +
            kActorEntityContextOffset
        );
}


[[nodiscard]]
inline
const EntityContextView*
entityContextFromActor(
    const void* actor
) noexcept {

    return
        entityContextFromActor(

            const_cast<
                void*
            >(
                actor
            )
        );
}


} // namespace levifreecam::game
