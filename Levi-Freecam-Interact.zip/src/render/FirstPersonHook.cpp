#include "render/FirstPersonHook.hpp"

#include <android/log.h>

#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include <cstdint>
#include <string_view>


namespace levifreecam::render {


namespace {


constexpr char
    kLogTag[] =
        "Levi Freecam";


constexpr std::string_view
    kMinecraftLibrary =
        "libminecraftpe.so";


/*
 * ============================================================
 * Stage-2E validated render predicates
 * ============================================================
 *
 * Exact target:
 *
 * Android ARM64 libminecraftpe.so
 * Build ID:
 *
 * b480c79a54f33d6e4f0d63a131673e3daf749911
 *
 * ------------------------------------------------------------
 * PLAYER MODEL PREDICATE
 * ------------------------------------------------------------
 *
 * RVA:
 *
 *     0x94523A4
 *
 * Native behavior:
 *
 * - resolves RenderCameraComponent
 * - obtains render-camera EntityId
 * - checks CameraRenderPlayerModelComponent
 *   hash 0x838D12E1
 * - returns bool
 *
 * The 36-byte sequence below has exactly ONE match in the
 * entire target libminecraftpe.so.
 *
 * No BL/B/ADRP instruction exists inside this signature.
 */
constexpr std::string_view
    kRenderPlayerModelPredicateSignature =

        "FF C3 01 D1 "
        "FD 7B 04 A9 "
        "F5 2B 00 F9 "
        "F4 4F 06 A9 "
        "FD 03 01 91 "
        "55 D0 3B D5 "
        "A8 16 40 F9 "
        "A8 83 1F F8 "
        "00 C8 40 F9";


/*
 * ------------------------------------------------------------
 * FIRST-PERSON OBJECTS PREDICATE
 * ------------------------------------------------------------
 *
 * RVA:
 *
 *     0x9742DBC
 *
 * Native behavior:
 *
 * - resolves active/render camera
 * - checks CameraRenderFirstPersonObjectsComponent
 *   hash 0xE15A7944
 * - performs vanilla local-player/client checks
 * - returns bool
 *
 * Direct render caller:
 *
 *     0x9741118:
 *
 *       BL  0x9742DBC
 *       TBZ W0,#0,skipRender
 *
 * Therefore:
 *
 * false = do NOT render first-person objects
 *
 * The 40-byte sequence below has exactly ONE match in the
 * target libminecraftpe.so.
 *
 * No branch/ADRP is present inside these first 40 bytes.
 */
constexpr std::string_view
    kRenderFirstPersonObjectsPredicateSignature =

        "FF 83 01 D1 "
        "FD 7B 03 A9 "
        "F5 23 00 F9 "
        "F4 4F 05 A9 "
        "FD C3 00 91 "
        "55 D0 3B D5 "
        "F3 03 00 AA "
        "A8 16 40 F9 "
        "A8 83 1F F8 "
        "08 C8 40 F9";


using RenderPredicateFn =
    bool (*)(
        void* self
    );


RenderPredicateFn
    gOriginalRenderPlayerModel =
        nullptr;


RenderPredicateFn
    gOriginalRenderFirstPersonObjects =
        nullptr;


void*
    gRenderPlayerModelTarget =
        nullptr;


void*
    gRenderFirstPersonObjectsTarget =
        nullptr;


std::uintptr_t
    gRenderPlayerModelAddress =
        0;


std::uintptr_t
    gRenderFirstPersonObjectsAddress =
        0;


/*
 * ============================================================
 * Player body predicate
 * ============================================================
 */


bool renderPlayerModelDetour(
    void* self
) {

    /*
     * Always allow vanilla function to execute.
     *
     * This preserves any internal temporary references,
     * validation and cleanup performed by Minecraft.
     */
    const auto original =
        gOriginalRenderPlayerModel;


    const bool vanillaResult =

        original != nullptr

            ? original(
                self
            )

            : false;


    /*
     * Freecam:
     *
     * force LocalPlayer body render eligibility.
     */
    if (
        FirstPersonHook::
            instance().
            isEnabled()
    ) {

        return true;
    }


    return vanillaResult;
}


/*
 * ============================================================
 * First-person object predicate
 * ============================================================
 */


bool renderFirstPersonObjectsDetour(
    void* self
) {

    /*
     * Keep vanilla internal work intact.
     */
    const auto original =
        gOriginalRenderFirstPersonObjects;


    const bool vanillaResult =

        original != nullptr

            ? original(
                self
            )

            : false;


    /*
     * Freecam:
     *
     * hide:
     *
     * - player hand
     * - held first-person item
     * - first-person object render pass
     */
    if (
        FirstPersonHook::
            instance().
            isEnabled()
    ) {

        return false;
    }


    return vanillaResult;
}


} // namespace


FirstPersonHook&
FirstPersonHook::instance()
    noexcept {

    static FirstPersonHook
        hook;


    return hook;
}


/*
 * ============================================================
 * Install
 * ============================================================
 */


bool
FirstPersonHook::install()
    noexcept {

    if (
        mInstalled.load(
            std::memory_order_acquire
        )
    ) {

        return true;
    }


    /*
     * Resolve BOTH targets first.
     *
     * Never leave a partially resolved render profile.
     */
    const std::uintptr_t
        bodyAddress =

            pl::memory::
                resolveSignature(

                    kRenderPlayerModelPredicateSignature,

                    kMinecraftLibrary
                );


    if (
        bodyAddress ==
        0
    ) {

        __android_log_print(
            ANDROID_LOG_ERROR,
            kLogTag,
            "Stage-2E body render predicate signature not found"
        );


        return false;
    }


    const std::uintptr_t
        firstPersonAddress =

            pl::memory::
                resolveSignature(

                    kRenderFirstPersonObjectsPredicateSignature,

                    kMinecraftLibrary
                );


    if (
        firstPersonAddress ==
            0

        ||

        firstPersonAddress ==
            bodyAddress
    ) {

        __android_log_print(
            ANDROID_LOG_ERROR,
            kLogTag,
            "Stage-2E first-person predicate signature invalid"
        );


        return false;
    }


    /*
     * =========================================================
     * Hook body predicate
     * =========================================================
     */


    void*
        bodyOriginal =
            nullptr;


    void*
        bodyTarget =

            reinterpret_cast<
                void*
            >(
                bodyAddress
            );


    const int bodyResult =

        pl::memory::
            hook(

                bodyTarget,

                reinterpret_cast<
                    void*
                >(
                    &renderPlayerModelDetour
                ),

                &bodyOriginal,

                pl::memory::
                    HookPriority::
                        Normal
            );


    if (
        bodyResult !=
            0

        ||

        bodyOriginal ==
            nullptr
    ) {

        __android_log_print(
            ANDROID_LOG_ERROR,
            kLogTag,

            "Stage-2E body predicate hook failed %d",

            bodyResult
        );


        return false;
    }


    gOriginalRenderPlayerModel =

        reinterpret_cast<
            RenderPredicateFn
        >(
            bodyOriginal
        );


    gRenderPlayerModelTarget =
        bodyTarget;


    gRenderPlayerModelAddress =
        bodyAddress;


    /*
     * =========================================================
     * Hook first-person-object predicate
     * =========================================================
     */


    void*
        firstPersonOriginal =
            nullptr;


    void*
        firstPersonTarget =

            reinterpret_cast<
                void*
            >(
                firstPersonAddress
            );


    const int firstPersonResult =

        pl::memory::
            hook(

                firstPersonTarget,

                reinterpret_cast<
                    void*
                >(
                    &renderFirstPersonObjectsDetour
                ),

                &firstPersonOriginal,

                pl::memory::
                    HookPriority::
                        Normal
            );


    if (
        firstPersonResult !=
            0

        ||

        firstPersonOriginal ==
            nullptr
    ) {

        /*
         * Roll back body hook.
         *
         * Never leave only one half of render override active.
         */
        pl::memory::
            unhook(

                gRenderPlayerModelTarget,

                reinterpret_cast<
                    void*
                >(
                    &renderPlayerModelDetour
                )
            );


        gOriginalRenderPlayerModel =
            nullptr;


        gRenderPlayerModelTarget =
            nullptr;


        gRenderPlayerModelAddress =
            0;


        __android_log_print(
            ANDROID_LOG_ERROR,
            kLogTag,

            "Stage-2E first-person predicate hook failed %d",

            firstPersonResult
        );


        return false;
    }


    gOriginalRenderFirstPersonObjects =

        reinterpret_cast<
            RenderPredicateFn
        >(
            firstPersonOriginal
        );


    gRenderFirstPersonObjectsTarget =
        firstPersonTarget;


    gRenderFirstPersonObjectsAddress =
        firstPersonAddress;


    mEnabled.store(
        false,
        std::memory_order_release
    );


    mInstalled.store(
        true,
        std::memory_order_release
    );


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,

        "Stage-2E render predicates installed body=%p firstPerson=%p",

        gRenderPlayerModelTarget,
        gRenderFirstPersonObjectsTarget
    );


    return true;
}


/*
 * ============================================================
 * Uninstall
 * ============================================================
 */


void
FirstPersonHook::uninstall()
    noexcept {

    if (
        !mInstalled.load(
            std::memory_order_acquire
        )
    ) {

        return;
    }


    /*
     * Disable override BEFORE removing trampoline.
     */
    mEnabled.store(
        false,
        std::memory_order_release
    );


    /*
     * Remove first-person predicate first.
     */
    if (
        gRenderFirstPersonObjectsTarget !=
        nullptr
    ) {

        pl::memory::
            unhook(

                gRenderFirstPersonObjectsTarget,

                reinterpret_cast<
                    void*
                >(
                    &renderFirstPersonObjectsDetour
                )
            );
    }


    /*
     * Then player body predicate.
     */
    if (
        gRenderPlayerModelTarget !=
        nullptr
    ) {

        pl::memory::
            unhook(

                gRenderPlayerModelTarget,

                reinterpret_cast<
                    void*
                >(
                    &renderPlayerModelDetour
                )
            );
    }


    gOriginalRenderFirstPersonObjects =
        nullptr;


    gOriginalRenderPlayerModel =
        nullptr;


    gRenderFirstPersonObjectsTarget =
        nullptr;


    gRenderPlayerModelTarget =
        nullptr;


    gRenderFirstPersonObjectsAddress =
        0;


    gRenderPlayerModelAddress =
        0;


    mInstalled.store(
        false,
        std::memory_order_release
    );
}


bool
FirstPersonHook::installed()
    const noexcept {

    return
        mInstalled.load(
            std::memory_order_acquire
        );
}


/*
 * ============================================================
 * Toggle
 * ============================================================
 */


void
FirstPersonHook::setEnabled(
    bool enabled
) noexcept {

    mEnabled.store(
        enabled,
        std::memory_order_release
    );


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,

        "Stage-2E camera render override %s",

        enabled

            ? "ON (body=show, first-person objects=hide)"

            : "OFF (vanilla)"
    );
}


bool
FirstPersonHook::isEnabled()
    const noexcept {

    return
        mEnabled.load(
            std::memory_order_acquire
        );
}


/*
 * ============================================================
 * Addresses
 * ============================================================
 */


std::uintptr_t
FirstPersonHook::targetAddress()
    noexcept {

    return
        gRenderFirstPersonObjectsAddress;
}


std::uintptr_t
FirstPersonHook::bodyTargetAddress()
    noexcept {

    return
        gRenderPlayerModelAddress;
}


std::uintptr_t
FirstPersonHook::firstPersonTargetAddress()
    noexcept {

    return
        gRenderFirstPersonObjectsAddress;
}


} // namespace levifreecam::render
