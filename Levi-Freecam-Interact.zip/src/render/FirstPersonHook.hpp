#pragma once

#include <atomic>
#include <cstdint>


namespace levifreecam::render {


class FirstPersonHook final {

public:

    static FirstPersonHook&
    instance()
        noexcept;


    bool install()
        noexcept;


    void uninstall()
        noexcept;


    [[nodiscard]]
    bool installed()
        const noexcept;


    /*
     * CAM render override.
     *
     * enabled:
     *
     * - render player body = TRUE
     * - render first-person objects = FALSE
     *
     * disabled:
     *
     * - return completely to vanilla predicates
     */
    void setEnabled(
        bool enabled
    ) noexcept;


    [[nodiscard]]
    bool isEnabled()
        const noexcept;


    /*
     * Compatibility accessor.
     *
     * Returns first-person predicate address.
     */
    [[nodiscard]]
    static std::uintptr_t
    targetAddress()
        noexcept;


    [[nodiscard]]
    static std::uintptr_t
    bodyTargetAddress()
        noexcept;


    [[nodiscard]]
    static std::uintptr_t
    firstPersonTargetAddress()
        noexcept;


private:

    FirstPersonHook()
        = default;


private:

    std::atomic_bool
        mInstalled{
            false
        };


    std::atomic_bool
        mEnabled{
            false
        };
};


} // namespace levifreecam::render
