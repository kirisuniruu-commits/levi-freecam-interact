#include "hooks/PlayerHook.hpp"

#include "core/FreecamController.hpp"
#include "core/PlayerFreezeController.hpp"

#include "game/RawEcs.hpp"

#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include <android/log.h>

#include <cstddef>
#include <cstdint>
#include <string_view>


namespace levifreecam::hooks {


namespace {


constexpr char kLogTag[] =
    "Levi Freecam";


constexpr std::string_view
    kMinecraftLibrary =
        "libminecraftpe.so";


/*
 * ============================================================
 * LocalPlayer::normalTick
 * ============================================================
 */


constexpr std::string_view
    kNormalTickSignature =

        "? ? ? FC "
        "? ? ? A9 "
        "? ? ? A9 "
        "? ? ? A9 "
        "? ? ? A9 "
        "? ? ? A9 "
        "? ? ? A9 "
        "? ? ? 91 "
        "? ? ? D1 "
        "54 D0 3B D5 "
        "F3 03 00 AA "
        "? ? ? F9 "
        "? ? ? F8 "
        "? ? ? 39";


/*
 * ============================================================
 * PlayerMoveSystemsImpl::_doPlayerPreMoveSystem
 * ============================================================
 *
 * Exact Android binary:
 *
 * RVA 0x10A12BE8
 */


constexpr std::string_view
    kPlayerPreMoveSignature =

        "FF 03 01 D1 "
        "FD 7B 01 A9 "
        "F5 13 00 F9 "
        "F4 4F 03 A9 "
        "FD 43 00 91 "
        "53 D0 3B D5 "
        "68 16 40 F9 "
        "E8 07 00 F9 "
        "49 08 40 B9 "
        "4A 00 40 F9 "
        "8B 00 40 F9 "
        "88 08 40 B9";


/*
 * ============================================================
 * SneakTriggerSystem::doActionTick
 * ============================================================
 *
 * Exact Android binary:
 *
 * RVA:
 *
 *     0xB4A9E58
 *
 * Signature uniqueness:
 *
 *     1 / 1
 *
 * First 56 bytes contain no branch/ADRP.
 *
 * Disassembly proves:
 *
 * PlayerAction bit 11:
 *     StartSneaking
 *
 * PlayerAction bit 12:
 *     StopSneaking
 *
 * These feed:
 *
 * ActorFlags::Sneaking
 */


constexpr std::string_view
    kSneakActionSignature =

        "FD 7B BA A9 "
        "FC 6F 01 A9 "
        "FA 67 02 A9 "
        "F8 5F 03 A9 "
        "F6 57 04 A9 "
        "F4 4F 05 A9 "
        "FD 03 00 91 "
        "38 00 40 F9 "
        "F3 03 04 AA "
        "F5 03 03 AA "
        "F6 03 02 AA "
        "F7 03 01 AA "
        "F4 03 00 AA "
        "F9 03 18 AA";


/*
 * ============================================================
 * PlayerActionComponent
 * ============================================================
 *
 * Android exact native executor uses:
 *
 *     stride = 0x140
 *
 * first 8 bytes:
 *
 *     player action bitset
 */


constexpr std::uint32_t
    kPlayerActionComponentHash =
        0x3000F399U;


constexpr std::size_t
    kPlayerActionComponentSize =
        0x140;


constexpr std::uint64_t
    kStartSneakingBit =

        std::uint64_t{1}
        <<
        11;


constexpr std::uint64_t
    kStopSneakingBit =

        std::uint64_t{1}
        <<
        12;


struct PlayerActionComponentRaw final {

    std::uint64_t
        mPlayerActions{
            0
        };


    std::byte
        mRemaining[
            kPlayerActionComponentSize -
            sizeof(
                std::uint64_t
            )
        ]{};
};


static_assert(
    sizeof(
        PlayerActionComponentRaw
    ) ==
        kPlayerActionComponentSize
);


/*
 * ============================================================
 * Function ABIs
 * ============================================================
 */


using NormalTickFn =
    void (*)(
        void*
    );


using PlayerPreMoveFn =
    void (*)(
        void* strictEntityContext,
        game::MoveRequestComponent* moveRequest,
        const void* stateVectorComponent,
        void* vanillaClientGameplayComponent,
        void* optionalOnGround,
        void* wasOnGroundModifier
    );


/*
 * Actual doActionTick body uses X0..X4.
 *
 * X1 = PlayerActionComponent*
 */
using SneakActionFn =
    void (*)(
        void* strictEntityContext,
        PlayerActionComponentRaw* playerActions,
        void* actorDataFlags,
        void* actorDataDirtyFlags,
        void* boundingBoxModifier
    );


/*
 * ============================================================
 * Hook state
 * ============================================================
 */


NormalTickFn
    gOriginalNormalTick =
        nullptr;


PlayerPreMoveFn
    gOriginalPlayerPreMove =
        nullptr;


SneakActionFn
    gOriginalSneakAction =
        nullptr;


void*
    gNormalTickTarget =
        nullptr;


void*
    gPlayerPreMoveTarget =
        nullptr;


void*
    gSneakActionTarget =
        nullptr;


bool
    gLoggedNativeMovementBlock =
        false;


bool
    gLoggedSneakBlock =
        false;


/*
 * ============================================================
 * Helpers
 * ============================================================
 */


void neutralizeMoveRequest(
    game::MoveRequestComponent*
        request
) noexcept {

    if (
        request ==
        nullptr
    ) {

        return;
    }


    request->
        mPreCollisionSpeed =
            {};


    request->
        mSpeed =
            {};


    /*
     * Stage-2H:
     *
     * movement request itself may also carry
     * physical sneak status.
     */


    request->
        mSneaking =
            false;
}


[[nodiscard]]
void*
getTrackedLocalPlayer()
    noexcept {

    if (
        !FreecamController::
            instance().
            active()
    ) {

        return nullptr;
    }


    return

        PlayerFreezeController::
            instance().
            player();
}


[[nodiscard]]
bool isLocalPlayerMoveRequest(
    game::MoveRequestComponent*
        request
) noexcept {

    void*
        localPlayer =
            getTrackedLocalPlayer();


    if (
        localPlayer ==
            nullptr

        ||

        request ==
            nullptr
    ) {

        return false;
    }


    auto*
        localRequest =

            game::
                findComponent<
                    game::MoveRequestComponent
                >(
                    localPlayer,

                    game::
                        kMoveRequestComponentHash
                );


    return

        localRequest !=
            nullptr

        &&

        localRequest ==
            request;
}


[[nodiscard]]
bool isLocalPlayerAction(
    PlayerActionComponentRaw*
        actions
) noexcept {

    void*
        localPlayer =
            getTrackedLocalPlayer();


    if (
        localPlayer ==
            nullptr

        ||

        actions ==
            nullptr
    ) {

        return false;
    }


    auto*
        localActions =

            game::
                findComponent<
                    PlayerActionComponentRaw
                >(
                    localPlayer,
                    kPlayerActionComponentHash
                );


    return

        localActions !=
            nullptr

        &&

        localActions ==
            actions;
}


/*
 * ============================================================
 * Player movement filter
 * ============================================================
 */


void playerPreMoveDetour(
    void* strictEntityContext,
    game::MoveRequestComponent* moveRequest,
    const void* stateVectorComponent,
    void* vanillaClientGameplayComponent,
    void* optionalOnGround,
    void* wasOnGroundModifier
) {

    const bool
        freeze =

            isLocalPlayerMoveRequest(
                moveRequest
            );


    if (
        freeze
    ) {

        neutralizeMoveRequest(
            moveRequest
        );
    }


    const auto
        original =
            gOriginalPlayerPreMove;


    if (
        original !=
        nullptr
    ) {

        original(
            strictEntityContext,
            moveRequest,
            stateVectorComponent,
            vanillaClientGameplayComponent,
            optionalOnGround,
            wasOnGroundModifier
        );
    }


    if (
        freeze
    ) {

        /*
         * Re-zero anything vanilla rebuilt.
         */


        neutralizeMoveRequest(
            moveRequest
        );


        if (
            !gLoggedNativeMovementBlock
        ) {

            gLoggedNativeMovementBlock =
                true;


            __android_log_print(
                ANDROID_LOG_INFO,
                kLogTag,
                "Native LocalPlayer MoveRequest blocked; sneaking=false"
            );
        }
    }
}


/*
 * ============================================================
 * Sneak action filter
 * ============================================================
 */


void sneakActionDetour(
    void* strictEntityContext,
    PlayerActionComponentRaw* playerActions,
    void* actorDataFlags,
    void* actorDataDirtyFlags,
    void* boundingBoxModifier
) {

    const bool
        blockSneak =

            isLocalPlayerAction(
                playerActions
            );


    if (
        blockSneak
    ) {

        /*
         * Never allow physical LocalPlayer:
         *
         *     StartSneaking
         *
         * while freecam is active.
         */


        playerActions->
            mPlayerActions &=

                ~kStartSneakingBit;


        /*
         * Force vanilla SneakTriggerSystem to process:
         *
         *     StopSneaking
         *
         * This is preferable to raw ActorDataFlag writes
         * because vanilla itself updates dirty flags and
         * bounding-box state.
         */


        playerActions->
            mPlayerActions |=

                kStopSneakingBit;
    }


    const auto
        original =
            gOriginalSneakAction;


    if (
        original !=
        nullptr
    ) {

        original(
            strictEntityContext,
            playerActions,
            actorDataFlags,
            actorDataDirtyFlags,
            boundingBoxModifier
        );
    }


    if (
        blockSneak

        &&

        !gLoggedSneakBlock
    ) {

        gLoggedSneakBlock =
            true;


        __android_log_print(
            ANDROID_LOG_INFO,
            kLogTag,
            "Stage-2H physical sneak blocked: StartSneaking -> StopSneaking"
        );
    }
}


/*
 * ============================================================
 * LocalPlayer normalTick
 * ============================================================
 */


void normalTickDetour(
    void* localPlayer
) {

    auto&
        controller =

            FreecamController::
                instance();


    controller.
        onLocalPlayerPreTick(
            localPlayer
        );


    if (
        gOriginalNormalTick !=
        nullptr
    ) {

        gOriginalNormalTick(
            localPlayer
        );
    }


    controller.
        onLocalPlayerPostTick(
            localPlayer
        );
}


/*
 * ============================================================
 * Rollback helpers
 * ============================================================
 */


void rollbackNormalTick()
    noexcept {

    if (
        gNormalTickTarget !=
        nullptr
    ) {

        pl::memory::
            unhook(
                gNormalTickTarget,

                reinterpret_cast<
                    void*
                >(
                    &normalTickDetour
                )
            );
    }


    gOriginalNormalTick =
        nullptr;


    gNormalTickTarget =
        nullptr;
}


void rollbackPreMove()
    noexcept {

    if (
        gPlayerPreMoveTarget !=
        nullptr
    ) {

        pl::memory::
            unhook(
                gPlayerPreMoveTarget,

                reinterpret_cast<
                    void*
                >(
                    &playerPreMoveDetour
                )
            );
    }


    gOriginalPlayerPreMove =
        nullptr;


    gPlayerPreMoveTarget =
        nullptr;
}


} // namespace


/*
 * ============================================================
 * Install
 * ============================================================
 */


bool
PlayerHook::install() {

    if (
        mInstalled
    ) {

        return true;
    }


    /*
     * Resolve all targets FIRST.
     */


    const std::uintptr_t
        normalTickAddress =

            pl::memory::
                resolveSignature(
                    kNormalTickSignature,
                    kMinecraftLibrary
                );


    const std::uintptr_t
        playerPreMoveAddress =

            pl::memory::
                resolveSignature(
                    kPlayerPreMoveSignature,
                    kMinecraftLibrary
                );


    const std::uintptr_t
        sneakActionAddress =

            pl::memory::
                resolveSignature(
                    kSneakActionSignature,
                    kMinecraftLibrary
                );


    if (
        normalTickAddress ==
            0

        ||

        playerPreMoveAddress ==
            0

        ||

        sneakActionAddress ==
            0
    ) {

        __android_log_print(
            ANDROID_LOG_ERROR,
            kLogTag,

            "Stage-2H resolve failed normal=%p move=%p sneak=%p",

            reinterpret_cast<
                void*
            >(
                normalTickAddress
            ),

            reinterpret_cast<
                void*
            >(
                playerPreMoveAddress
            ),

            reinterpret_cast<
                void*
            >(
                sneakActionAddress
            )
        );


        return false;
    }


    /*
     * =========================================================
     * Hook normalTick
     * =========================================================
     */


    void*
        original =
            nullptr;


    gNormalTickTarget =

        reinterpret_cast<
            void*
        >(
            normalTickAddress
        );


    int result =

        pl::memory::
            hook(
                gNormalTickTarget,

                reinterpret_cast<
                    void*
                >(
                    &normalTickDetour
                ),

                &original,

                pl::memory::
                    HookPriority::Normal
            );


    if (
        result !=
            0

        ||

        original ==
            nullptr
    ) {

        gNormalTickTarget =
            nullptr;


        return false;
    }


    gOriginalNormalTick =

        reinterpret_cast<
            NormalTickFn
        >(
            original
        );


    /*
     * =========================================================
     * Hook PlayerMove
     * =========================================================
     */


    original =
        nullptr;


    gPlayerPreMoveTarget =

        reinterpret_cast<
            void*
        >(
            playerPreMoveAddress
        );


    result =

        pl::memory::
            hook(
                gPlayerPreMoveTarget,

                reinterpret_cast<
                    void*
                >(
                    &playerPreMoveDetour
                ),

                &original,

                pl::memory::
                    HookPriority::Normal
            );


    if (
        result !=
            0

        ||

        original ==
            nullptr
    ) {

        gPlayerPreMoveTarget =
            nullptr;


        rollbackNormalTick();


        return false;
    }


    gOriginalPlayerPreMove =

        reinterpret_cast<
            PlayerPreMoveFn
        >(
            original
        );


    /*
     * =========================================================
     * Hook native SneakTrigger action
     * =========================================================
     */


    original =
        nullptr;


    gSneakActionTarget =

        reinterpret_cast<
            void*
        >(
            sneakActionAddress
        );


    result =

        pl::memory::
            hook(
                gSneakActionTarget,

                reinterpret_cast<
                    void*
                >(
                    &sneakActionDetour
                ),

                &original,

                pl::memory::
                    HookPriority::Normal
            );


    if (
        result !=
            0

        ||

        original ==
            nullptr
    ) {

        gSneakActionTarget =
            nullptr;


        rollbackPreMove();
        rollbackNormalTick();


        return false;
    }


    gOriginalSneakAction =

        reinterpret_cast<
            SneakActionFn
        >(
            original
        );


    gLoggedNativeMovementBlock =
        false;


    gLoggedSneakBlock =
        false;


    mTargetAddress =
        normalTickAddress;


    mInstalled =
        true;


    __android_log_print(
        ANDROID_LOG_INFO,
        kLogTag,

        "Stage-2H hooks installed move=%p sneak=%p",

        gPlayerPreMoveTarget,
        gSneakActionTarget
    );


    return true;
}


/*
 * ============================================================
 * Uninstall
 * ============================================================
 */


void
PlayerHook::uninstall()
    noexcept {

    if (
        !mInstalled
    ) {

        return;
    }


    /*
     * Reverse installation order.
     */


    if (
        gSneakActionTarget !=
        nullptr
    ) {

        pl::memory::
            unhook(
                gSneakActionTarget,

                reinterpret_cast<
                    void*
                >(
                    &sneakActionDetour
                )
            );
    }


    gOriginalSneakAction =
        nullptr;


    gSneakActionTarget =
        nullptr;


    rollbackPreMove();
    rollbackNormalTick();


    gLoggedNativeMovementBlock =
        false;


    gLoggedSneakBlock =
        false;


    mTargetAddress =
        0;


    mInstalled =
        false;
}


bool
PlayerHook::installed()
    const noexcept {

    return
        mInstalled;
}


std::uintptr_t
PlayerHook::targetAddress()
    const noexcept {

    return
        mTargetAddress;
}


} // namespace levifreecam::hooks
